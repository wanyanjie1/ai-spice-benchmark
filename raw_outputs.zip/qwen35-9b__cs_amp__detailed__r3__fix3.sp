* Common-Source NMOS Amplifier Design
* Specs: |Av| = 10, VDD = 5V, f = 1kHz, No external load
* Model: NMOS level=1, vto=0.7, kp=200u, lambda=0.01

* --- Hand Calculation & Component Selection Comments ---
* Design Goal: |Av| = 10
* Parameters: VDD=5V, VTO=0.7V, KP=200uA/V^2, Lambda=0.01V^-1
* 
* Step 1: Choose Overdrive Voltage (Vov) and Gate Voltage (VGS)
* Let VGS = 1.5V => Vov = VGS - VTO = 0.8V
* 
* Step 2: Calculate Drain Current (ID)
* ID = 0.5 * KP * (Vov)^2
* ID = 0.5 * 200u * (0.8)^2 = 64 uA
* 
* Step 3: Calculate Transconductance (gm)
* gm = KP * Vov = 200u * 0.8 = 160 uS (or 0.16 mS)
* 
* Step 4: Determine Drain Resistor (RD) for Gain
* Ideal Av = -gm * RD. We want |Av| = 10.
* RD_ideal = 10 / gm = 10 / 0.00016 = 62,500 Ohms = 62.5 kOhm
* 
* Step 5: Check Saturation and Output Swing
* Voltage drop across RD = ID * RD = 64uA * 62.5k = 4V
* VDS = VDD - 4V = 1V
* Saturation Condition: VDS > Vov => 1V > 0.8V. (PASS)
* 
* Step 6: Bias Divider for Gate Voltage (VG = VGS = 1.5V)
* VG = VDD * R2 / (R1 + R2) => 1.5 = 5 * R2 / (R1+R2)
* Ratio R2/(R1+R2) = 0.3
* Choose standard values or exact: R1 = 70k, R2 = 30k works perfectly.

* --- Circuit Definition ---
* Power Supply
VDD VDD 0 DC 5

* Input Source (AC 1 at node 'in')
VIN in 0 AC 1

* Input Coupling Capacitor (10uF)
Cin in gate 10uF

* NMOS Transistor
* Nodes: Drain(out), Gate, Source, Bulk(ground)
M1 out gate source 0 NMOS1 L=1u W=1u

* Drain Resistor connected to output node 'out'
RD out VDD 62.5k

* Gate Bias Divider
R1 VDD gate 70k
R2 gate 0 30k

* Source connection (Directly to ground)
RS source 0 0

* --- Model Definition ---
.model NMOS1 nmos (level=1 vto=0.7 kp=200u lambda=0.01)

* --- Simulation Control ---
* Perform AC analysis from 1Hz to 1MHz with 10 points per decade
.ac dec 10 1 1Meg

.end
