* First-Order Passive RC Low-Pass Filter (fc = 1 kHz)

* Input AC Source
Vin in 0 DC 0 AC 1

* Filter Components
* R = 1.59155 kOhm and C = 100 nF yields fc = 1 / (2 * pi * R * C) = 1 kHz
R1 in out 1.59155k
C1 out 0 100n

* AC Analysis from 10 Hz to 100 kHz
.ac dec 100 10 100k

.end
