* Two-Stage Miller-Compensated CMOS Op Amp Design
* -----------------------------------------------------------------
* Specifications:
* Supply Voltage VDD = 5V
* Open-Loop Gain >= 60 dB
* Load Capacitance CL = 1 pF
* Miller Compensation Capacitor Cc = 2 pF
* Reference Current Iref = 20 uA
*
* Transistor Parameters:
* NMOS1: Level=1, Vto=0.7V, Kp=110uA/V^2, Lambda=0.04 V^-1
* PMOS1: Level=1, Vto=-0.7V, Kp=50uA/V^2,  Lambda=0.05 V^-1
*
* -----------------------------------------------------------------
* Hand Calculations & Device Sizing:
*
* 1. Bias Circuit (M6 & M5):
*    Iref = 20 uA flows through M6 (diode-connected NMOS).
*    Let (W/L)6 = 10u / 1u.
*    Vov6 = sqrt(2 * Iref / (Kp_n * (W/L)6)) = sqrt(40u / 1100u) = 0.191 V
*    VGS6 = Vtn + Vov6 = 0.7V + 0.191V = 0.891 V
*
*    Tail transistor M5:
*    Let (W/L)5 = 10u / 1u. Since VGS5 = VGS6 = 0.891V, I5 = 20 uA.
*    I1 = I2 = I5 / 2 = 10 uA.
*
* 2. First Stage Sizing (M1, M2, M3, M4):
*    Diff pair M1, M2: (W/L)1 = (W/L)2 = 20u / 1u.
*    gm1 = sqrt(2 * Kp_n * (W/L)1 * I1) = sqrt(2 * 110u * 20 * 10u) = 209.8 uS
*    ro1 = 1 / (lambda_n * I1) = 1 / (0.04 * 10u) = 2.5 Mohm
*
*    Active load mirror M3, M4 (PMOS):
*    Let (W/L)3 = (W/L)4 = 10u / 1u.
*    ro3 = 1 / (lambda_p * I3) = 1 / (0.05 * 10u) = 2.0 Mohm
*    First stage output resistance: Ro1 = ro1 || ro3 = 2.5M || 2.0M = 1.111 Mohm
*    First stage DC gain: Av1 = gm1 * Ro1 = 209.8 uS * 1.111 Mohm = 233.1 V/V (47.35 dB)
*
* 3. Second Stage Sizing (M7, M8):
*    Target bias current I7 = I8 = 100 uA.
*    Current mirror load M8 (NMOS):
*    Gate tied to vg_bias (VGS8 = VGS6 = 0.891V).
*    (W/L)8 = 5 * (W/L)6 = 50u / 1u to mirror 100 uA.
*    ro8 = 1 / (lambda_n * I8) = 1 / (0.04 * 100u) = 250 kohm
*
*    Driver M7 (PMOS):
*    In DC equilibrium, Vg7 = Vn1 = Vn3 = VDD - |VGS3|.
*    Vov3 = sqrt(2 * 10u / (50u * 10)) = 0.2 V => |VGS3| = 0.9 V.
*    Thus Vn1 = 4.1 V, and |VGS7| = VDD - Vn1 = 0.9 V => Vov7 = 0.2 V.
*    (W/L)7 = (2 * I7) / (Kp_p * Vov7^2) = (2 * 100u) / (50u * 0.04) = 100u / 1u.
*    gm7 = sqrt(2 * Kp_p * (W/L)7 * I7) = sqrt(2 * 50u * 100 * 100u) = 707.1 uS
*    ro7 = 1 / (lambda_p * I7) = 1 / (0.05 * 100u) = 200 kohm
*    Second stage output resistance: Ro2 = ro7 || ro8 = 200k || 250k = 111.1 kohm
*    Second stage DC gain: Av2 = gm7 * Ro2 = 707.1 uS * 111.1 kohm = 78.56 V/V (37.90 dB)
*
* 4. Total DC Gain:
*    Av_total = Av1 * Av2 = 233.1 * 78.56 = 18313 V/V = 85.25 dB (Exceeds 60 dB spec)
*
* 5. Transistor Saturation Verification:
*    - M6: VDS6 = VGS6 = 0.891V > Vov6 = 0.191V (SATURATED)
*    - M5: VDS5 = Vtail = 1.705V > Vov5 = 0.191V (SATURATED)
*    - M1, M2: VDS1,2 = 4.1V - 1.705V = 2.395V > Vov1,2 = 0.095V (SATURATED)
*    - M3, M4: |VDS3,4| = 0.9V > |Vov3,4| = 0.200V (SATURATED)
*    - M7: |VDS7| = 5V - 2.5V = 2.5V > |Vov7| = 0.200V (SATURATED)
*    - M8: VDS8 = 2.5V > Vov8 = 0.191V (SATURATED)
* -----------------------------------------------------------------

* Device Models
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05

* Power Supply & Bias Reference
Vdd vdd 0 DC 5
Iref vdd vg_bias DC 20u

* Input Signal (Non-Inverting Input = node 'in')
Vin in 0 DC 2.5 AC 1

* AC Open-Loop Testbench Feedback Loop (DC Bias Stabilization)
L1 out inn 1G
C1 inn 0 1

* First Stage (NMOS Diff Pair + PMOS Load)
M6 vg_bias vg_bias 0    0    NMOS1 W=10u L=1u
M5 vtail   vg_bias 0    0    NMOS1 W=10u L=1u
M1 n1      in      vtail 0    NMOS1 W=20u L=1u
M2 n3      inn     vtail 0    NMOS1 W=20u L=1u
M3 n1      n3      vdd  vdd  PMOS1 W=10u L=1u
M4 n3      n3      vdd  vdd  PMOS1 W=10u L=1u

* Second Stage (PMOS Common-Source + NMOS Load)
M7 out     n1      vdd  vdd  PMOS1 W=100u L=1u
M8 out     vg_bias 0    0    NMOS1 W=50u L=1u

* Compensation & Load Capacitors
Cc n1  out 2p
CL out 0   1p

* Simulation Commands
.op
.ac dec 10 1 100Meg

.end
