* First-order Passive RC Low-Pass Filter
* Target: -3dB cutoff at 1 kHz
* Topology: Vsource -> R -> C -> GND, Output at node between R and C

Vsource in 0 AC 1 DC 0
Rfilter in out 1.59155k
Cfilter out 0 100nF

.model Vsource vsource (voltage=0)
.model Rfilter resistor (r=1.59155k)
.model Cfilter capacitor (c=100n)

.ac dec 100 10 1Meg
.plot ac v(out)
.end
