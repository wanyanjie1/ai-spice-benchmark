* Two-Stage CMOS Operational Amplifier

* Transistor Models
.model NMOS NMOS (VTO=0.7 KP=120u LAMBDA=0.01 TOX=1e-8)
.model PMOS PMOS (VTO=-0.7 KP=40u LAMBDA=0.01 TOX=1e-8)

* Power Supply
VDD vdd 0 DC 5

* Input Sources
VIN in 0 DC 2.5 AC 1
VINM in_m 0 DC 2.5

* Bias Network
Rbias vdd vbias_n 39k
Mbias vbias_n vbias_n 0 0 NMOS W=10u L=1u

* Stage 1: Differential Input Pair with Active Mirror Load
M0 n_tail vbias_n 0 0 NMOS W=10u L=1u
M1 n_mirror in n_tail 0 NMOS W=50u L=1u
M2 n1 in_m n_tail 0 NMOS W=50u L=1u
M3 n_mirror n_mirror vdd vdd PMOS W=20u L=1u
M4 n1 n_mirror vdd vdd PMOS W=20u L=1u

* Stage 2: Common-Source Output Stage
M5 out n1 vdd vdd PMOS W=80u L=1u
M6 out vbias_n 0 0 NMOS W=20u L=1u

* Miller Compensation
Cc n1 out 2p

.ac dec 10 1 100MEG
.end
