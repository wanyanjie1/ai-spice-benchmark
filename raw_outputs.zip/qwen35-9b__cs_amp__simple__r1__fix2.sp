* Common-Source NMOS Amplifier Design
* Specifications: |Av| = 10, f = 1kHz, VDD = 5V
* Strategy: Bias transistor in saturation with Vout ~ 2.5V to avoid log(0) errors.

VDD drain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
Cin in gate 1uF
M1 drain out gate source NMOS L=1u W=40u
RL drain out 10k
Cout out 0 1uF

* Bias Network: Voltage divider to set Gate Voltage (Vg) and Source Grounded.
* We need Vgs > Vt (assume Vt=0.7). Let's target Vg = 2.5V.
* Simple voltage divider from VDD to ground at node 'gate' is risky for AC coupling if not careful,
* but here Cin blocks DC, so we just need a DC path to set Vg.
* Using two resistors to bias the gate directly:
Rbias1 gate 0 1M
Rbias2 gate VDD 1M
* This sets Vg approx at 2.5V (assuming symmetric divider). 
* With Vt=0.7, Vgs = 2.5V - 0V = 2.5V -> Strong conduction.
* To ensure stability and avoid floating nodes, we add a small resistor to source if needed,
* but here Source is grounded (0), so Vgs = Vg.

.model NMOS NMOS (LEVEL=1 VTO=0.7 KP=50u LAMBDA=0.02 CGSO=1p CGDO=1p CJ=0)

* AC Analysis settings to ensure clean sweep
.ac dec 10 10 1Meg
