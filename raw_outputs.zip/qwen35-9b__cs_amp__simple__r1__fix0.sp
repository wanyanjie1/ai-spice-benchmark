* Common-Source NMOS Amplifier Design
* Target: |Av| = 10 at 1 kHz, VDD = 5V

VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
M1 drain out gate source NMOS L=1u W=100u
Rs source 0 1k
RL drain out 10k
Cout out 0 1u

* Biasing setup: We need to set Vgs such that gm*Rd ≈ 10.
* Assuming Rd (RL) = 10k, we need gm ≈ 1 S.
* For a simple square law model approximation or typical process parameters:
* Let's define a specific NMOS model with reasonable parameters to achieve this gain.
* To get high gain, we operate in saturation.
* We will use a DC sweep or operating point analysis implicitly defined by the circuit values.
* However, without a .op command or specific biasing network (like a current source), 
* the transistor needs a gate voltage to turn on. Since no explicit Vbias is requested 
* and we must define models, we assume an ideal scenario where the user provides a DC offset 
* or we rely on the default operating point calculation if Vin had a DC component.
* To ensure a valid SPICE netlist that calculates a specific gain, we usually need a bias network.
* Let's add a simple voltage divider to bias the gate for saturation.

Vbias gate 0 DC 2.5
R1 gate Vbias 1M
R2 gate Vin 1M ; This creates a path but Vin is AC only. 
* Correction: Standard biasing uses two resistors from VDD to GND connected to Gate.
* Let's replace the simple Vin connection with a proper bias network + AC coupling.

* Revised Topology for Stable Bias:
VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
Cin in gate 1u
M1 drain out gate source NMOS L=1u W=100u
Rs source 0 1k
RL drain out 10k
Cout out 0 1u
* Bias Network:
Rg1 gate node_bias 100k
Rg2 node_bias 0 100k
Vbias node_bias 0 DC 2.5

.model NMOS NMOS (LEVEL=1 VTO=0.7 KP=100u LAMBDA=0.02 CGSO=0 CGDO=0 CJ=0)

* Note: The gain Av = -gm * (RL || ro). 
* With RL=10k, if gm is around 0.8-0.9 S, gain is ~8-9. 
* To get exactly 10, we might need higher gm or larger ro.
* Let's adjust W to increase gm. If KP=100uA/V^2, Id = 0.5*KP*(W/L)*(Vgs-Vt)^2.
* Let's try W=200u for higher current.
* Recalculating model parameters in the .model line to ensure gain > 10 is possible.
* Actually, let's just provide a robust netlist where the bias point is set by the resistors.
* With Vbias=2.5V, Vgs = 2.5 - 0 (if Rs=0) or less if Rs>0.
* Let's remove Rs to maximize gain for simplicity in this specific design request, 
* or keep small Rs for stability? The prompt implies a standard CS amp.
* Let's assume Rs=0 for max gain calculation simplicity unless specified otherwise.
* Wait, the previous draft had Rs=1k. If Rs is unbypassed, gain drops significantly.
* We need a bypass capacitor on Rs or set Rs=0.
* Let's set Rs=0 to maximize gain potential.

* Finalizing Netlist:
VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
Cin in gate 1u
M1 drain out gate source NMOS L=1u W=200u
RL drain out 10k
Cout out 0 1u
* Bias Network to set Vgs ~ 1.5V (assuming Vt=0.7) -> Id ~ 0.5mA, gm ~ sqrt(2*KP*W/L*Id)
* Let's calculate: If Vgs=1.5, Vov=0.8. Id = 0.5 * 100u * (200/1) * 0.8^2 = 12.8 mA? Too high for 5V supply with 10k load.
* Let's lower W or adjust model KP.
* Let's use a standard model and rely on the solver to find the Q-point.
* To ensure gain=10, we need gm*Rd = 10 => gm = 1S (since Rd=10k).
* Id = gm^2 * Rds? No. gm = sqrt(2*KP*(W/L)*Id). 
* Let's just define the model and circuit. The exact gain depends on the Q-point found by SPICE.
* We will add a DC voltage source to the gate to fix the bias, as AC sources alone don't set DC.

VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
Cin in gate 1u
M1 drain out gate source NMOS L=1u W=200u
RL drain out 10k
Cout out 0 1u
* Biasing: Use a voltage divider to set Gate Voltage.
Rg1 gate node_bias 100k
Rg2 node_bias 0 100k
Vbias node_bias 0 DC 2.5

.model NMOS NMOS (LEVEL=1 VTO=0.7 KP=50u LAMBDA=0.05 CGSO=1p CGDO=1p CJ=0)

* Explanation of parameters:
* VDD = 5V.
* Gate biased at ~2.5V via divider. Source is grounded (Rs=0 for max gain).
* Vgs = 2.5 - 0.7 = 1.8V.
* Id = 0.5 * 50u * (200/1) * (1.8)^2 = 16.2 mA. This is too high for 5V supply with 10k load (would drop >16V).
* We need to reduce W or increase VTO or adjust KP.
* Let's reduce W to 5u and increase L? Or just trust SPICE to converge.
* Actually, let's make the circuit robust by adding a source resistor Rs with a bypass capacitor if needed, 
* but for "Common Source", usually Rs is bypassed or zero.
* Let's try W=10u, L=1u.
* Id = 0.5 * 50u * 10 * (1.8)^2 = 0.81 mA.
* Vdsat = Vgs - Vt = 1.1V.
* Vd = 5 - Id*10k = 5 - 8.1V -> Cutoff! 
* We need higher Vdd or lower current.
* Let's adjust the bias voltage to be lower, say 1.8V? Then Vgs=1.1V, Vov=0.4V.
* Id = 0.5 * 50u * 10 * 0.4^2 = 0.04 mA = 40uA.
* Vd = 5 - 0.4V = 4.6V. Saturation holds.
* gm = 2*Id / Vov = 80uA / 0.4V = 0.2 S.
* Gain = gm * Rd = 0.2 * 10k = 2. Too low.

* To get Gain=10, we need gm=1S (with 10k load).
* gm = 1S => Id = 0.5 * gm * Vov.
* If Vov = 0.5V, Id = 0.25A? No. Id = 0.5 * KP * W/L * Vov^2.
* Let's solve for W: 1 = sqrt(2 * 50u * W/1u * Id). 
* This is getting iterative. Let's just provide a netlist that SPICE will simulate correctly.
* I will set W=100u, L=1u, Vbias=1.8V (Vgs=1.1V, Vov=0.4V).
* Id = 0.5 * 50u * 100 * 0.16 = 0.4 mA.
* gm = sqrt(2 * 50u * 100 * 0.4mA) = sqrt(4) = 2 S? 
* Formula: gm = sqrt(2*KP*(W/L)*Id). 
* Id = 0.4mA. KP=50u. W/L=100.
* gm = sqrt(2 * 50e-6 * 100 * 0.4e-3) = sqrt(4e-6) = 2e-3 S = 2 mS.
* Gain = 2mS * 10k = 20. Close enough to 10? No, we want 10.
* We need gm=1mS. So Id should be lower or W smaller.
* Let's set W=25u. 
* Id = 0.5 * 50u * 25 * 0.16 = 0.1 mA.
* gm = sqrt(2 * 50e-6 * 25 * 0.1e-3) = sqrt(2.5e-7) = 0.5 mS. Gain = 5.
* Okay, let's just define the model and circuit. The exact gain depends on the specific .model parameters and bias point found by SPICE. 
* I will configure the netlist to be a standard CS amplifier. The user can tweak W/L in simulation if exact 10 is critical without iterative tuning, but for the purpose of the prompt "Design...", providing a valid topology with defined models is key.
* I will use a larger VDD or adjust RL? No, VDD=5V fixed.
* Let's assume the question asks for the netlist structure.
* I will provide a netlist with reasonable parameters that *can* achieve gain 10 (e.g., by adjusting W in simulation).
* However, to be precise: 
* Target Av = -10. Rd = 10k. Need gm = 1 mS.
* Id = gm^2 * Rds? No.
* Let's pick W=50u, L=1u, Vbias=1.9V (Vgs=1.2V, Vov=0.5V).
* Id = 0.5 * 50u * 50 * 0.25 = 0.3125 mA.
* gm = sqrt(2 * 50e-6 * 50 * 0.3125e-3) = sqrt(1.56e-6) = 1.25 mS.
* Gain = 1.25mS * 10k = 12.5. Close.
* Let's reduce W to 40u. 
* Id = 0.5 * 50u * 40 * 0.25 = 0.25 mA.
* gm = sqrt(2 * 50e-6 * 40 * 0.25e-3) = sqrt(1e-6) = 1 mS.
* Gain = 10. Perfect.

Final Params: W=40u, L=1u, Vbias=1.9V (assuming Vt=0.7).
Wait, if Vbias is set by a divider, the voltage at gate is fixed.
Let's use a simple voltage source Vbias connected to Gate directly for simplicity in netlist, or a divider. 
The prompt says "Design...", so I will include a bias network.

