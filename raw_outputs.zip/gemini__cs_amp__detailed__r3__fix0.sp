* Single-Stage Common-Source NMOS Amplifier Design
*
* Hand Calculations:
* --------------------------------------------------
* Given Specs & Model Parameters:
*   VDD = 5 V, Target |Av| = 10 (20 dB) at 1 kHz
*   VTO = 0.7 V, KP = 200 uA/V^2, LAMBDA = 0.01 V^-1
*
* 1. Choose Operating Point (ID and VGS) & Device Sizing:
*    Set W = 10u, L = 1u -> W/L = 10
*    Target VGS = 1.2 V -> Overdrive VOV = VGS - VTO = 1.2 - 0.7 = 0.5 V
*    ID = 0.5 * KP * (W/L) * (VGS - VTO)^2
*       = 0.5 * 200u * 10 * (0.5)^2 = 0.25 mA
*
* 2. Compute Transconductance (gm):
*    gm = 2 * ID / (VGS - VTO) = (2 * 0.25 mA) / 0.5 V = 1.0 mS
*
* 3. Choose Drain Resistor (RD) for Target Gain (|Av| ~= 10):
*    |Av| ~= gm * RD  =>  RD = 10 / gm = 10 / 1.0 mS = 10 kOhm
*    (Including ro ~= 1 / (lambda * ID) = 400 kOhm, Av = gm * (RD || ro) ~= 9.76 V/V ~= 19.8 dB)
*
* 4. Check Saturation Condition:
*    VDS = VDD - ID * RD = 5 V - (0.25 mA * 10 kOhm) = 2.5 V
*    VOV = VGS - VTO = 0.5 V
*    Since VDS (2.5 V) > VGS - VTO (0.5 V), MOSFET stays in saturation.
*
* 5. Gate Bias Network (R1, R2):
*    VG = VGS = 1.2 V
*    VG = VDD * R2 / (R1 + R2) => R1 / R2 = (VDD - VG) / VG = 3.8 / 1.2 = 3.167
*    Choose R2 = 240 kOhm, R1 = 760 kOhm (Rin = R1 || R2 = 182.4 kOhm)
*    Input pole with Cin = 10uF is at f = 1 / (2*pi*Rin*Cin) ~= 0.087 Hz << 1 kHz.

* Power Supply
VDD vdd 0 DC 5

* Input Signal Source
V1 in 0 DC 0 AC 1

* Coupling Capacitor
C1 in gate 10u

* Gate Bias Resistors
R1 vdd gate 760k
R2 gate 0 240k

* Drain Resistor
RD vdd out 10k

* NMOS Transistor
M1 out gate 0 0 NMOS1 W=10u L=1u

* MOSFET Model Definition
.model NMOS1 nmos level=1 vto=0.7 kp=200u lambda=0.01

* Analysis Command
.ac dec 20 1 100k

.end
