V1 in AC 1
R1 in out 1k
C1 out gnd 1u
