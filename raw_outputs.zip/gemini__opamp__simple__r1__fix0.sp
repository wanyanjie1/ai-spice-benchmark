Two-Stage CMOS Operational Amplifier

* Power Supply
VDD vdd 0 DC 5.0

* Input Signals
Vin in 0 DC 2.5 AC 1
Vin_neg in_neg 0 DC 2.5

* Bias Current Generator
Iref vdd vbias DC 20u
Mbias vbias vbias 0 0 NMOS W=10u L=1u

* Stage 1: Differential Input Pair with PMOS Current Mirror Load
M1 n1 in tail 0 NMOS W=50u L=1u
M2 n2 in_neg tail 0 NMOS W=50u L=1u
M3 n1 n1 vdd vdd PMOS W=20u L=1u
M4 n2 n1 vdd vdd PMOS W=20u L=1u
M5 tail vbias 0 0 NMOS W=20u L=1u

* Stage 2: Common-Source Second Stage
M6 out n2 vdd vdd PMOS W=200u L=1u
M7 out vbias 0 0 NMOS W=100u L=1u

* Miller Compensation Network
Cc n2 n_cc 3p
Rc n_cc out 1k

* Transistor Models
.model NMOS NMOS (VTO=0.7 KP=100u LAMBDA=0.01 GAMMA=0.4)
.model PMOS PMOS (VTO=-0.7 KP=40u LAMBDA=0.02 GAMMA=0.4)

* AC Analysis
.ac dec 10 1 100Meg

.end
