* Common-Source NMOS Amplifier with Voltage Gain = 10 (20 dB)

* Power Supply
Vdd vdd 0 DC 5

* Input AC Source with DC Bias driving node 'in'
Vin in 0 DC 1.5 AC 1

* Drain Resistor
RD vdd out 10k

* NMOS Transistor (Drain Gate Source Body)
M1 out in 0 0 NMOS_MODEL W=1u L=1u

* MOSFET Model definition
.model NMOS_MODEL NMOS (LEVEL=1 VTO=1.0 KP=2m LAMBDA=0)

* AC Analysis around 1 kHz
.ac dec 10 100 10k

.end
