Here is the corrected SPICE netlist:
* Two-stage Miller-compensated CMOS op amp design
* Open-loop gain >= 60 dB at low frequency, VDD = 5 V, CL = 1 pF
* NMOS differential pair with PMOS current-mirror load
* NMOS tail current source biased by a current mirror (e.g. 20uA reference)
* PMOS common-source second stage with NMOS current-source load
* Miller capacitor Cc (~2pF) from first-stage output to 'out'
* Define NMOS and PMOS models
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05
* NMOS differential pair
M1 in1 in2 vdd vdd NMOS1 W=10u L=1u
M2 in1 in2 vdd vdd NMOS1 W=10u L=1u
M3 in1 vdd vdd vdd PMOS1 W=10u L=1u
M4 in2 vdd vdd vdd PMOS1 W=10u L=1u
* PMOS current-mirror load
M5 vdd vdd vdd vdd PMOS1 W=20u L=1u
M6 vdd vdd vdd vdd PMOS1 W=20u L=1u
* NMOS tail current source
M7 vdd vdd vdd vdd NMOS1 W=10u L=1u
M8 vdd vdd vdd vdd NMOS1 W=10u L=1u
* PMOS common-source second stage
M9 vdd vdd vdd vdd PMOS1 W=10u L=1u
M10 vdd vdd vdd vdd PMOS1 W=10u L=1u
* NMOS current-source load
M11 vdd vdd vdd vdd NMOS1 W=10u L=1u
M12 vdd vdd vdd vdd NMOS1 W=10u L=1u
* Miller capacitor
Cc out vdd 2p
* AC test bench
Vin in 0 DC 2.5 AC 1
L1 out inn 1G
C1 inn 0 1
* Output node