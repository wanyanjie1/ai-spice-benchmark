* Two-Stage CMOS Operational Amplifier
* VDD = 5V, Gain >= 60dB, Miller Compensated
* Nodes: 'in' (Non-inverting input), 'out' (Output)

* Supply Voltage
Vdd 0 DC 5

* Device Models
.model NMOS nmos (level=1 vto=0.4 kp=100u lambda=0.1 cgdo=0 cgd0=0)
.model PMOS pmos (level=1 vto=-0.4 kp=50u lambda=0.15 cgdo=0 cgd0=0)

* Bias Network for Tail Current Source Gate
* Generates a voltage to bias the tail current source NMOS
Rb1 bias_node 0 1M
Rb2 Vdd bias_node 1M

* Tail Current Source (NMOS)
* Connected between Diff Pair sources and Ground
Mtail NMOS tail_node 0 bias_node Vdd L=0.18u W=20u model=NMOS

* Differential Input Pair (NMOS)
* Mdiff1: Non-inverting input connected to node 'in'
Mdiff1 NMOS diff_p tail_node in Vdd L=0.18u W=5u model=NMOS
* Mdiff2: Inverting input connected to Ground (AC ground for single-ended test)
Mdiff2 NMOS diff_n tail_node 0 Vdd L=0.18u W=5u model=NMOS

* Active Load for Differential Pair (PMOS Current Mirror)
* Reference branch (Diode connected PMOS)
Mref_p PMOS ref_gate Vdd Vdd Vdd L=0.18u W=20u model=PMOS
* Mirror branches connected to diff pair drains
Mload1 PMOS diff_p out_load_1 Vdd ref_gate L=0.18u W=40u model=PMOS
Mload2 PMOS diff_n out_load_2 Vdd ref_gate L=0.18u W=40u model=PMOS

* Second Stage: Common Source (NMOS) with PMOS Load
* Input to second stage is the drain of Mdiff1/Mload1 junction (Node: diff_p)
Mcs NMOS out diff_p Vdd Vdd L=0.18u W=2u model=NMOS

* Active Load for Second Stage (PMOS Current Source)
Mcs_load PMOS out Vdd Vdd Vdd L=0.18u W=20u model=PMOS

* Miller Compensation Capacitor
* Connected between Output ('out') and the internal node of the first stage ('diff_p')
Cc diff_p out 5pF

* AC Source at Non-Inverting Input 'in'
Vin in 0 AC 1

* Analysis Command
.ac dec 100 1Hz 1GHz
.end
