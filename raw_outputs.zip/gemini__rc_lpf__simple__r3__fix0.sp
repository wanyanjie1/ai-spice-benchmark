* First-Order Passive RC Low-Pass Filter
* Cutoff frequency (fc) = 1 kHz
* fc = 1 / (2 * pi * R * C)
* Selection: R = 1k Ohm, C = 159.155 nF

* AC Input Source
Vin in 0 DC 0 AC 1

* Passive RC Filter Circuit
R1 in out 1k
C1 out 0 159.155n

* Analysis Command
.ac dec 100 10 100k

.end
