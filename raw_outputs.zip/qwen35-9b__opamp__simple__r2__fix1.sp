* Two-Stage CMOS Operational Amplifier
* Topology: NMOS Differential Pair + PMOS Current Mirror Load + PMOS Common Source 2nd Stage + NMOS Active Load
* Supply: VDD = 5V, GND = 0V
* Target Gain: > 60dB

* --- Technology Parameters (Simplified for Simulation) ---
* Using Level 1 models with reasonable parameters for a 0.18um-like process simulation
.model nmos NMOS (LEVEL=1 VTO=0.4 KP=100u GAMMA=0.5 LAMBDA=0.02 CGSO=2p CGDO=2p CJ=1e-3 CJSW=1e-3)
.model pmos PMOS (LEVEL=1 VTO=-0.4 KP=-50u GAMMA=0.5 LAMBDA=0.02 CGSO=2p CGDO=2p CJ=1e-3 CJSW=1e-3)

* --- DC Supply Nodes ---
VDD vdd 0 DC 5
VGND gnd 0 DC 0

* --- Bias Voltage Sources (Calculated for ~200uA Tail Current and Mid-Rail Operation) ---
* We need specific gate voltages to ensure all transistors are in saturation.
* Estimated biases:
*   NMOS Tail/Gate Common Mode: ~1.1V
*   PMOS Load/Gate Common Mode: ~4.4V
*   Second Stage Bias (NMOS Load): ~0.7V

VB_tail tail_gate 0 DC 1.1
VB_load load_gate 0 DC 4.4
VB_2nd_stage_2nd_stage_gate 0 DC 0.7

* --- First Stage: Differential Pair & Active Load ---
* M1, M2: NMOS Input Pair (W=18u, L=0.36u)
* M3, M4: PMOS Current Mirror Load (W=36u, L=0.36u - sized to match current roughly)
* Tail Current Source: M_tail (NMOS)

M1 drain node_x in tail_gate L=0.36u W=18u model=nmos
M2 drain node_x in_ tail_gate L=0.36u W=18u model=nmos

* PMOS Mirror Load
* M3 is diode-connected (Gate tied to Drain)
* M4 mirrors M3
M3 drain node_x load_gate L=0.36u W=36u model=pmos
M4 drain out node_x L=0.36u W=36u model=pmos

* Wait, standard topology correction:
* The output of the first stage is usually taken from the drain of the mirror transistor (M4).
* However, to get high gain, we need the current mirror to convert differential current to single-ended voltage.
* Correct connection:
* M1 drain -> M3 drain -> Node A
* M2 drain -> M4 drain -> Node B (Output of Stage 1)
* M3 gate -> M3 drain (Node A)
* M4 gate -> M3 gate (Node A)
* The second stage input is connected to Node B.
* Let's re-verify the netlist connections for stability.
* If M3 and M4 are matched, and M1/M2 are matched:
* DC Current in M1 = DC Current in M2 = I_tail/2.
* M3 carries I_M1. M4 carries I_M2.
* Since it's a mirror, Vgs(M3) = Vgs(M4).
* The voltage at Node B (drain of M4) is VDD - Vsg(M4).
* This node drives the second stage.

* --- Tail Current Source ---
M_tail drain tail_gate gnd load_gate L=0.36u W=72u model=nmos
* Note: The gate of M_tail is connected to VB_tail (1.1V).
* Wait, in the netlist above I used 'tail_gate' as a node name for the bias source and also as a drain connection?
* Let's clean up node names.

* --- Revised Netlist with Clean Node Names ---

* --- Supply ---
VDD vdd 0 DC 5
VGND gnd 0 DC 0

* --- Bias Voltage Sources ---
VB1 tail_gate 0 DC 1.1   * Gate for Input Pair and Tail Current
VB2 load_gate 0 DC 4.4   * Gate for PMOS Load Mirror
VB3 out_gate 0 DC 0.7    * Gate for NMOS Active Load of 2nd Stage

* --- First Stage Devices ---
* NMOS Differential Pair
M1 drain node_x in tail_gate L=0.36u W=18u model=nmos
M2 drain node_x in_ tail_gate L=0.36u W=18u model=nmos

* PMOS Current Mirror Load
* M3: Diode connected, connects VDD to node_x (via source/drain swap logic? No, Source to VDD)
* Standard PMOS: Source at VDD, Drain at Node.
M3 drain node_x load_gate L=0.36u W=36u model=pmos
M4 drain out node_x L=0.36u W=36u model=pmos

* Wait, if M3 and M4 are connected as a mirror:
* Source of M3 -> VDD
* Drain of M3 -> Node X
* Gate of M3 -> Node X (Diode connected)
* Source of M4 -> VDD
* Drain of M4 -> Node Y (Output of Stage 1)
* Gate of M4 -> Node X
* This works.

* --- Tail Current Source ---
M_tail drain tail_gate gnd VB1 L=0.36u W=72u model=nmos
* Wait, M_tail drain should connect to the sources of M1 and M2.
* In my previous schematic logic:
* M1 source -> M2 source -> M_tail drain.
* Let's define a node 'tail_node' for the connection.

M1 drain node_x in tail_node L=0.36u W=18u model=nmos
M2 drain node_x in_ tail_node L=0.36u W=18u model=nmos
M_tail drain tail_node gnd VB1 L=0.36u W=72u model=nmos

* --- Second Stage Devices ---
* M5: PMOS Common Source (Input from node_x)
* M6: NMOS Active Load (Diode connected)
* Connection:
* M5 Source -> VDD
* M5 Drain -> out
* M5 Gate -> node_x
* M6 Drain/Gate -> out
* M6 Source -> GND

M5 drain out node_x L=0.36u W=36u model=pmos
M6 drain out gnd VB3 L=0.36u W=72u model=nmos

* --- Input/Output Sources ---
* AC Source at 'in'
AC_IN in 0 AC 1 DC 1.1
* Note: The DC level of the AC source must match the bias voltage (VB1 = 1.1V).
* So AC_IN is connected to node 'in'.

* --- Miller Compensation Capacitor ---
C_comp node_x out 2pF

* --- Analysis Commands ---
.OPTIONS POST2=2 RELTOL=0.001
.TRAN 1n 1u
.AC DEC 100 1Hz 100MHz
.OP
.END
