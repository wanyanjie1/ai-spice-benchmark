.model RCLowPass RC R=10k C=15.9n
Vinput in 0 AC 1
R1 in out 10k
C1 out 0 15.9n
