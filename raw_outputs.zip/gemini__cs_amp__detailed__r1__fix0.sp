* Single-Stage Common-Source NMOS Amplifier Design
*
* Hand Calculation Steps:
* 1. Choose VGS = 1.2 V, giving overdrive voltage Vov = VGS - VTO = 1.2 V - 0.7 V = 0.5 V.
* 2. Calculate bias current ID:
*    ID = 0.5 * KP * (W/L) * (VGS - VTO)^2 = 0.5 * 200u * 1 * (0.5)^2 = 25 uA
* 3. Compute transconductance gm:
*    gm = 2 * ID / (VGS - VTO) = 2 * 25u / 0.5 = 100 uS (0.1 mS)
* 4. Choose RD to achieve |Av| ~= gm * RD = 10:
*    RD = 10 / gm = 10 / 100uS = 100 kOhm
* 5. Check saturation condition:
*    VDS = VDD - ID * RD = 5 V - (25 uA * 100 kOhm) = 2.5 V
*    VDS (2.5 V) > VGS - VTO (0.5 V), so MOSFET is operating in saturation.
* 6. Gate Bias Divider (VG = 1.2 V with VDD = 5 V):
*    VG = VDD * R2 / (R1 + R2) => R2 / (R1 + R2) = 1.2 / 5.0 = 0.24
*    Choosing R2 = 240 kOhm and R1 = 760 kOhm.

* Power Supply
VDD vdd 0 DC 5

* Input AC Signal Source
V1 in 0 DC 0 AC 1

* Coupling Capacitor
Cin in gate 10u

* Gate Resistor Bias Divider
R1 vdd gate 760k
R2 gate 0 240k

* Drain Load Resistor
RD vdd out 100k

* MOSFET Transistor
M1 out gate 0 0 NMOS1 W=10u L=10u

* Device Model
.model NMOS1 nmos level=1 vto=0.7 kp=200u lambda=0.01

* AC Analysis around 1 kHz
.ac dec 10 100 10k

.end
