* First-Order Passive RC Low-Pass Filter
* fc = 1 / (2 * pi * R * C) = 1 kHz
* R1 = 1.59155 kOhm, C1 = 100 nF

* AC Input Source
Vin in 0 AC 1

* Passive Filter Components
R1 in out 1.59155k
C1 out 0 100n

* Frequency Analysis
.ac dec 20 10 100k

.end
