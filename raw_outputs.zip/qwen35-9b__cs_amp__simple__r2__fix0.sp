* Common-Source NMOS Amplifier Design
* Target: Gain = 10 (20 dB), f = 1 kHz, VDD = 5V
VDD vdd 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
M1 drain gate source 0 NMOS
RD drain out 1k
RS source 0 100k
Cout out 0 1uF
Cin in 0 1uF
* NMOS Model Definition (W/L = 10um/1um for reasonable gain)
* AC Analysis Setup
.AC DEC 100 10Hz 1MHz
.PROBE
.END