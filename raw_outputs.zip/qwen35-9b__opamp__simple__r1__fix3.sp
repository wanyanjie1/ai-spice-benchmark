* Two-Stage CMOS Operational Amplifier
* VDD = 5V, Gain >= 60dB, Miller Compensated
* Topology: PMOS Diff Pair + NMOS Current Mirror Load (Stage 1)
*          NMOS Common Source + PMOS Current Source Load (Stage 2)

* Supply Voltage
Vdd out_node 0 DC 5

* Device Models (Level 1 for robustness in basic simulations)
.model NMOS nmos (level=1 vto=-0.4 kp=100u lambda=0.1 cgdo=0 cgd0=0)
.model PMOS pmos (level=1 vto=0.4 kp=50u lambda=0.15 cgdo=0 cgd0=0)

* --- Bias Generation Circuit ---
* We create a stable bias voltage for the tail current source and second stage load.
* A simple diode-connected PMOS stack can generate a reference, but a resistor divider 
* with a buffer or direct connection is often safer for convergence in Level 1.
* Here we use a dedicated bias branch to set V_bias.
Rbias1 Vdd Vbias 1M
Rbias2 Vbias 0 1M
* This sets Vbias approx at 2.5V. 
* For PMOS tail (Source at Vdd), Vgs = 2.5 - 5 = -2.5V. |Vgs| > |Vth| (0.4V). OK.
* For PMOS load of stage 2 (Source at Vdd), same logic applies.

* --- Tail Current Source (PMOS) ---
* Connected between VDD and the source of the differential pair.
Mtail PMOS tail_node Vdd Vbias Vdd L=0.18u W=20u model=PMOS

* --- Differential Input Pair (PMOS) ---
* Mdiff1: Non-inverting input connected to node 'in'
Mdiff1 PMOS diff_p tail_node in Vdd L=0.18u W=5u model=PMOS
* Mdiff2: Inverting input connected to Ground (AC ground for single-ended test)
Mdiff2 PMOS diff_n tail_node 0 Vdd L=0.18u W=5u model=PMOS

* --- Active Load for Differential Pair (NMOS Current Mirror) ---
* Reference branch (Diode connected NMOS) - Gate drives the mirror
* Connected between Ground and VDD. Drain/Gate tied together.
Mref_n NMOS ref_gate 0 Vdd L=0.18u W=20u model=NMOS

* Mirror branches connected to diff pair drains
* Mload1 connects to drain of Mdiff1 (diff_p)
Mload1 NMOS diff_p out_load_1 ref_gate Vdd L=0.18u W=40u model=NMOS
* Mload2 connects to drain of Mdiff2 (diff_n) - usually tied to output or internal node
Mload2 NMOS diff_n out_load_2 ref_gate Vdd L=0.18u W=40u model=NMOS

* --- Second Stage: Common Source (NMOS) with PMOS Load ---
* Input to second stage is the drain of Mdiff1/Mload1 junction (Node: diff_p)
Mcs NMOS out diff_p Vdd Vdd L=0.18u W=2u model=NMOS

* Active Load for Second Stage (PMOS Current Source)
* Connected between Output and VDD. Gate biased by Vbias.
Mcs_load PMOS out Vdd Vbias Vdd L=0.18u W=20u model=PMOS

* --- Miller Compensation Capacitor ---
* Connected between Output ('out') and the internal node of the first stage ('diff_p')
Cc diff_p out 5pF

* --- AC Source at Non-Inverting Input 'in' ---
Vin in 0 AC 1

* --- Analysis Command ---
.ac dec 100 1Hz 1GHz
.end
