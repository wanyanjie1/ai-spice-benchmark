* Single-stage Common-Source NMOS Amplifier Design
* Specs: |Av| = 10, VDD = 5V, f = 1kHz (AC analysis)
* Model: level=1, vto=0.7, kp=200u, lambda=0.01
* --- Hand Calculation & Component Selection Comments ---
* Design Goal: |Av| = gm * RD ≈ 10
* Let's choose a drain current ID = 1 mA for reasonable power and transconductance.
* With VDD = 5V, we need to ensure saturation: VDS > VGS - VTO.
* Assume VGS = 2.0 V (Gate overdrive Vov = VGS - VTO = 1.3 V).
* Calculate gm: gm = 2 * ID / (VGS - VTO) = 2 * 1mA / 1.3V ≈ 1.538 mS.
* Required RD for Av = 10: RD = 10 / gm = 10 / 1.538mS ≈ 6.5 kΩ.
* Let's pick standard value RD = 6.5k (or close like 6.49k).
* Check Saturation Voltage: VDS(sat) = VGS - VTO = 1.3V.
* We need Vout > 1.3V.
* DC Operating Point:
*   V_Drain = VDD - ID * RD = 5V - 1mA * 6.5kΩ = 5V - 6.5V = -1.5V (Impossible!).
* Correction: The calculated RD drops too much voltage for ID=1mA with VDD=5V if we want Vout > 1.3V.
* Re-evaluating constraints:
*   Max allowed voltage drop across RD = VDD - VDS(sat) = 5V - 1.3V = 3.7V.
*   Therefore, max ID with RD chosen for gain is limited, or we must lower RD and accept lower gm?
*   Actually, Av = -gm * RD. If we reduce RD to fit in voltage headroom, Av drops.
*   Let's try a different approach: Set VDS = 2.5V (mid-rail) for stability.
*   Then V_RD_max = 5V - 2.5V = 2.5V.
*   If we want |Av|=10, and max RD is limited by voltage headroom...
*   Let's iterate:
*   Try ID = 0.5 mA.
*   VGS needed for saturation? Let's pick VGS = 1.8V -> Vov = 1.1V.
*   gm = 2 * 0.5mA / 1.1V = 0.909 mS.
*   Required RD = 10 / 0.909mS = 11 kΩ.
*   Voltage drop across RD = 0.5mA * 11kΩ = 5.5V (Too high, exceeds VDD).
*   Conclusion: With VDD=5V and VTO=0.7V, achieving |Av|=10 is very difficult with a simple resistor load because the required gm*RD product conflicts with the supply voltage headroom for saturation.
*   Let's try maximizing ID to get higher gm, allowing smaller RD? No, smaller RD reduces gain.
*   Wait, Av = -gm * RD. To get high Av, we need high gm AND high RD. High RD requires low ID (to keep Vdrop < VDD). Low ID lowers gm.
*   Let's find the theoretical limit:
*   VDS >= Vov. VDD = ID*RD + VDS >= ID*RD + Vov.
*   Av = - (2*ID/Vov) * RD.
*   Substitute RD <= (VDD - VDS)/ID.
*   |Av| <= (2*ID/Vov) * (VDD - VDS)/ID = 2*(VDD-VDS)/Vov.
*   To maximize |Av|, we need minimum Vov and minimum VDS(min).
*   Let VDS = Vov (edge of saturation). Then |Av| <= 2*(VDD - Vov)/Vov = 2*(VDD/Vov) - 2.
*   If Vov = 0.1V (very high overdrive? No, VGS=0.8), then |Av| <= 2*(4.9/0.1)-2 = 96.
*   But kp is small (200u). ID = 0.5 * kp * (Vov)^2.
*   If Vov = 0.1V, ID = 0.5 * 200u * 0.01 = 1uA. Very low current.
*   Then RD = (VDD - VDS)/ID = 4.9V / 1uA = 4.9 MΩ.
*   gm = 2*1uA/0.1V = 20uS.
*   Av = 20uS * 4.9MΩ = 98. This works!
*   So we should operate at low current to get high gain with limited supply.
*   Let's choose Vov = 0.2V (VGS = 0.9V).
*   ID = 0.5 * 200u * (0.2)^2 = 4 uA.
*   gm = 2 * 4uA / 0.2V = 40 uS.
*   Max V_RD = VDD - VDS(sat) = 5V - 0.2V = 4.8V.
*   RD_max = 4.8V / 4uA = 1.2 MΩ.
*   Av = gm * RD = 40uS * 1.2MΩ = 48. This is > 10.
*   We can tune RD to get exactly 10.
*   Let's pick ID = 5 uA (slightly higher for noise margin, still low).
*   Vov = 0.2V -> VGS = 0.9V.
*   gm = 2 * 5uA / 0.2V = 50 uS.
*   Target Av = 10 => RD = 10 / 50uS = 200 kΩ.
*   Check Voltage Drop: V_RD = ID * RD = 5uA * 200kΩ = 1.0 V.
*   V_Drain = 5V - 1.0V = 4.0V.
*   V_Source = 0V.
*   V_DS = 4.0V.
*   V_ov = 0.2V.
*   Is V_DS > V_ov? 4.0 > 0.2. Yes, deep saturation.
*   Bias Divider: Need VG = 0.9V. Use two resistors R1 (top), R2 (bottom).
*   Let's pick a divider current of 10x ID = 50uA to minimize loading? Or standard 100k/100k?
*   If we use large RD (200k), the gate leakage is negligible, but divider loading matters.
*   Let's set divider current ~ 100uA (much larger than ID=5uA).
*   R2 = VG / I_div = 0.9V / 100uA = 9 kΩ.
*   R1 = (VDD - VG) / I_div = 4.1V / 100uA = 41 kΩ.
*   Input Capacitor: 10uF (given).
*   Output Node: Drain directly to output node `out`.
* --- SPICE Netlist Construction ---
VDD VDD 0 DC 5
Vin in 0 AC 1
Cin in gate 10u
M1 drain gate source 0 NMOS1 L=1u W=1u
RD drain VDD 0
R2 gate 0 {9k}
R1 VDD gate {41k}
Vgate_dummy gate 0 DC 0 ; Dummy to define node if needed, but bias resistors set it.
.model NMOS1 nmos (level=1 vto=0.7 kp=200u lambda=0.01)
* AC Analysis at 1kHz
.ac dec 1 1k 1k
.print ac V(out) V(in)
.plot ac mag(V(out)/V(in))
.end