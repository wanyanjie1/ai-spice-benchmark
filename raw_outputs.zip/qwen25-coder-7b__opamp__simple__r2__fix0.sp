* Two-stage CMOS operational amplifier design
* Define NMOS and PMOS transistors
.model NMOS NMOS L=1u W=10u
.model PMOS PMOS L=1u W=10u
* Define voltage sources
VDD 1 0 5
VSS 2 0 0
* Define input AC source
* Differential input pair
M1 3 4 1 2 NMOS
M2 3 4 1 2 PMOS
* Common-source second stage
M3 5 6 4 0 NMOS
M4 5 6 4 0 PMOS
* Miller compensation
M5 7 8 6 0 PMOS
M6 7 8 6 0 NMOS
* Output node
Rout 8 0 1k
* Connect input to differential pair
V1 1 0 AC 1
* Connect output to load
Rload 6 0 1k
* Ground nodes
VSS 2 0
VDD 1 0