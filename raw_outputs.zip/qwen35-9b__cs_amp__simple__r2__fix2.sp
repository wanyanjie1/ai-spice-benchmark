* Common-Source NMOS Amplifier Design (Corrected)
* Target: Gain = 10 (20 dB), f = 1 kHz, VDD = 5V
* Issue in previous design: Drain resistor RD was too small (1k), resulting in excessive gain.
* Fix: Increase RD to ~4.7k to lower the intrinsic gain and set bias point correctly.

VDD vdd 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
M1 drain gate source 0 NMOS
RD drain out 4.7k
RS source 0 100k
Cout out 0 1uF
Cin in 0 1uF

* NMOS Model Definition (W/L = 10um/1um)
.model NMOS nmos (LEVEL=1 VTO=0.7 KP=110u GAMMA=0.5 LAMBDA=0.02 CGSO=2n CGDO=2n CJ=4f CGBO=2f)

* AC Analysis Setup
.AC DEC 100 10Hz 1MHz
.END
