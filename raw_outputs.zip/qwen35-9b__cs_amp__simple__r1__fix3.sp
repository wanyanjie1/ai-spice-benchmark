* Common-Source NMOS Amplifier Design
* Target: Gain = 10 (20 dB) at 1 kHz, VDD = 5V
* Strategy: Bias Vgs to ~1.1V for low overdrive, use Rd=1k to achieve gm*Rd=10.

VDD drain 0 DC 5
Vin in 0 AC 1
Rsig in gate 100
Cin in gate 1uF

* Bias Network to set Vg = 1.1V (Vt=0.7, Vov=0.4V)
* Divider ratio: 1.1/5 = 0.22
Rbias1 gate 0 39k
Rbias2 gate VDD 11k

M1 drain out gate source NMOS L=1u W=500u
RL drain out 1k
Cout out 0 1uF

* Device Model
.model NMOS NMOS (LEVEL=1 VTO=0.7 KP=50u LAMBDA=0.02 CGSO=1p CGDO=1p CJ=0)

* AC Analysis
.ac dec 10 10 1Meg
