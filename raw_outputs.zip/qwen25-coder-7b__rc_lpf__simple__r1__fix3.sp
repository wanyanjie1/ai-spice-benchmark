Here is the corrected netlist:
.model R1 resistor r=1k
.model C1 capacitor c=1u
V1 in 0 ac 1
R2 out 0 r=1k
C2 out 0 c=1u
.tran 1us 1ms