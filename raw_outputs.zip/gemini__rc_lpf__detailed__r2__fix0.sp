* First-Order Passive RC Low-Pass Filter
*
* Hand Calculation:
* Target cutoff frequency: fc = 1 kHz
* Transfer function formula: fc = 1 / (2 * pi * R * C)
* Selected standard capacitor value: C = 100 nF (100e-9 F)
* Calculate Resistor:
* R = 1 / (2 * pi * fc * C)
* R = 1 / (2 * pi * 1000 * 100e-9)
* R = 1 / (6.2831853e-4) = 1591.55 ohms
*
* Passband Gain = 0 dB (1 V/V at DC)

* Input Signal Source
V1 in 0 AC 1

* Filter Components
R1 in out 1591.55
C1 out 0 100n

* AC Analysis Command (10 Hz to 100 kHz)
.ac dec 20 10 100k

.end
