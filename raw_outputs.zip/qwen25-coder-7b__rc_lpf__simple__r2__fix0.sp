.model RCLowPass RC R=1k C=1u
Vinput in 0 AC 1
R1 in out 1k
C1 out 0 1u
.model RCLowPass RC R=1k C=1u
