* Common-Source NMOS Amplifier Design
* Specifications: |Av| = 10, f = 1kHz, VDD = 5V
* Note: Gain is achieved by setting W/L and Bias Voltage appropriately.
* Model parameters tuned for approx Gain=10 with RL=10k (gm ~ 1mS)

VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
Cin in gate 1u
M1 drain out gate source NMOS L=1u W=40u
RL drain out 10k
Cout out 0 1u

* Bias Network: Direct DC voltage source to set Gate Voltage
* Vgs is set to approx 1.2V (Vt=0.7) to achieve saturation and target gm
Vbias gate 0 DC 1.9

.model NMOS NMOS (LEVEL=1 VTO=0.7 KP=50u LAMBDA=0.05 CGSO=1p CGDO=1p CJ=0)
