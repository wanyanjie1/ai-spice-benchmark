.model rc_filter Rser 1k Cpar 1u
V1 in AC 1
R1 in out Rser
C1 out gnd Cpar
