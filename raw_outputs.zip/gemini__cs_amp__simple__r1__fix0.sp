* Common-Source NMOS Amplifier
* Voltage Gain: |Av| = 10 (20 dB) at 1 kHz
* Supply: VDD = 5V

* Power Supply
Vdd vdd 0 DC 5

* Input AC Source
Vin in 0 DC 0 AC 1

* Input Coupling Capacitor
Cin in g 1u

* Gate Biasing Resistors (Sets Vg = 1.4V)
R1 vdd g 720k
R2 g 0 280k

* Drain Load Resistor
Rd vdd out 4.08k

* NMOS Transistor (Drain=out, Gate=g, Source=0, Body=0)
M1 out g 0 0 NMOS1 W=6.25u L=1u

* Device Model
.model NMOS1 NMOS (LEVEL=1 VTO=1.0 KP=1m LAMBDA=0.01)

* AC Analysis at 1 kHz
.ac lin 1 1k 1k

.end
