* Corrected Common-Source NMOS Amplifier Design
* Specs: |Av| = 10, VDD = 5V, Model: nmos level=1 vto=0.7 kp=200u lambda=0.01
* Fix: Increased L to 10um and adjusted W/ID to target gm*Rd = 10.
* Hand Calculation Steps:
* 1. Target Vov (VGS - VTO) = 0.4 V for linearity.
* 2. Set VGS = 0.7 + 0.4 = 1.1 V.
* 3. Choose ID = 200uA to keep power low and gm manageable.
* 4. Calculate gm = 2 * ID / Vov = 2 * 200uA / 0.4V = 1 mS (1 mA/V).
* 5. Target |Av| = 10 => RD = 10 / gm = 10 kOhm.
* 6. Check Saturation: V_D = 5V - (200uA * 10k) = 3V. V_DS = 3V > 0.4V (OK).
* 7. Bias Network: VG = 1.1V. Divider current ~20uA.
*    R2 (Gate to Gnd) = 1.1V / 20uA = 55 kOhm.
*    R1 (VDD to Gate) = (5V - 1.1V) / 20uA = 195 kOhm.
* 8. Device Dimensions: L=10um, W calculated from Id equation or chosen to match model limits.
*    Using Level 1 model: Id = 0.5 * kp * (W/L) * (Vgs-Vto)^2
*    200uA = 0.5 * 200u * (W/10um) * (0.4)^2
*    200e-6 = 100e-6 * (W/10e-6) * 0.16
*    200e-6 = 1.6e-6 * W
*    W = 125 um.

VDD VDD 0 DC 5
VIN in 0 AC 1
CIN in gate 10uF
M1 out gate source 0 NMOS1 L=10u W=125u
RD out VDD 0 10k
R1 VDD gate 195k
R2 gate 0 55k
RS source 0 0
.model NMOS1 nmos (level=1 vto=0.7 kp=200u lambda=0.01)
.ac dec 10 10 1Meg
.end
