* Common-Source NMOS Amplifier Design (Corrected)
* Target: |Av| = 10 at 1 kHz, VDD = 5V
* Previous issue: Device parameters (KP, LAMBDA) were too high/low leading to excessive gain.
* Fix: Adjusted W/L ratio and added a source degeneration resistor (Rs) to control gain magnitude.
* Also added coupling capacitors for proper DC biasing isolation if needed, but here using simple bias setup.
* Note: To get exactly |Av|=10 with Rs=0 requires specific gm*Rd. With Rs > 0, Gain approx -gm*(Rd||RL)/(1+gm*Rs).
* Let's design for Gain ~ -10 using a reasonable W/L and adding Source Degeneration.

VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
M1 drain out gate source NMOS L=1u W=50u
Rs source 0 200
RL drain out 10k
Cout out 0 1u

.model NMOS nmos (LEVEL=1 VTO=0.7 KP=100u GAMMA=0 PHI=0.4 LAMBDA=0.05 CGSO=20n CGDO=20n CJ=1e-3 MJ=0.5 PB=0.7)
