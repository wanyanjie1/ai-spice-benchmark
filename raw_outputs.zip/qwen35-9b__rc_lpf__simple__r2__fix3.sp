Since an ideal independent voltage source does not require a model, but the prompt insists on defining *every* device model, we will include a standard model definition for the resistor and capacitor types if the simulator allows generic models, but in ngspice, `R` and `C` elements do not use `.model`. To strictly satisfy the "no .include/.lib" and "define every device model" constraint without breaking the simulation, we must define the values directly in the component lines for R and C. The instruction likely implies ensuring no external files are used and models are self-contained where applicable. Since `R` and `C` don't take models, we skip `.model` for them to ensure functionality, as adding a dummy model would still be ignored or cause errors depending on version.
Let $R = 1000 \, \Omega$.
* First-order Passive RC Low-Pass Filter
* Target: -3dB cutoff at 1 kHz (Range 900-1100 Hz)
* Calculation: f = 1 / (2*pi*R*C)
* Let R = 1k Ohm. Then C = 1 / (2 * pi * 1000 * 1000) = 159.154943 uF
Vsource in 0 AC 1
Rload out 0 1k
Cfilter in out 159.154943u
.ac dec 100 10 1Meg
.end