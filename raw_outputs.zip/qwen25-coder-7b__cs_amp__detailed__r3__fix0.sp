* Single-stage common-source NMOS amplifier design

* Define the NMOS model
.model NMOS1 nmos level=1 vto=0.7 kp=200u lambda=0.01

* Define the input AC source
V1 in 0 DC 0 AC 1

* Define the resistor divider for gate bias
R1 1 2 10k
R2 2 0 1k
VDD 2 0 DC 5

* Define the input coupling capacitor
C1 in 1 10uF

* Define the drain resistor
RD out 0 1k

* Define the NMOS transistor
M1 out in 0 0 NMOS1

* Calculate ID and VGS
* Av = gm * RD
* 10 = gm * 1k
* gm = 10 / 1k = 0.01 S
* gm = 2 * ID / (VGS - VTO)
* 0.01 = 2 * ID / (VGS - 0.7)
* ID = (0.01 * (VGS - 0.7)) / 2
* Let's assume VGS = 2V for simplicity
* ID = (0.01 * (2 - 0.7)) / 2 = 0.00625 A

* Check if the MOSFET stays in saturation
* VDS = VDD - VGS = 5 - 2 = 3V
* VGS - VTO = 2 - 0.7 = 1.3V
* Since VDS > VGS - VTO, the MOSFET is in saturation

* Define the current source for ID
I1 0 0 DC 0.00625

* Define the output node
out 0 0

* Define the ground node
0 0 0
