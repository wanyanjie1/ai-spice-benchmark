* Common-Source NMOS Amplifier Design
* Specs: |Av| = 10, VDD = 5V, Model: nmos level=1 vto=0.7 kp=200u lambda=0.01
* Hand Calculation Steps:
* 1. Choose ID = 1 mA to ensure reasonable gm and power consumption.
* 2. Assume overdrive voltage (Vov) = VGS - VTO = 0.4 V for good linearity.
* 3. Calculate VGS = VTO + Vov = 0.7 + 0.4 = 1.1 V.
* 4. Calculate gm = 2 * ID / Vov = 2 * 1mA / 0.4V = 5 mS (or 5 mA/V).
* 5. Target |Av| = gm * RD = 10 => RD = 10 / gm = 10 / 0.005 = 2 kOhm.
* 6. Check Saturation: VDS > Vov.
*    V_D = VDD - ID*RD = 5V - 1mA*2kOhm = 3V.
*    V_S = 0V.
*    V_DS = 3V. Since 3V > 0.4V, the device is in saturation.
* 7. Bias Network: Need VG = 1.1V at Gate. Use divider R1 (top) and R2 (bottom).
*    Let R2 connect Gate to Ground. R1 connects VDD to Gate.
*    Current through divider should be ~10x ID for stability? Or standard rule of thumb.
*    Let's pick a divider current of 50uA (approx 1/20th of ID).
*    R2 = VG / I_div = 1.1V / 50uA = 22 kOhm.
*    R1 = (VDD - VG) / I_div = (5V - 1.1V) / 50uA = 78 kOhm.
*    Input coupling cap: 10uF from 'in' to Gate.
*    Output node is Drain ('out'). No output capacitor.
VDD VDD 0 DC 5
VIN in 0 AC 1
CIN in gate 10uF
M1 drain gate source 0 NMOS1 L=1u W=100u
RD drain VDD 0
R1 VDD gate 78k
R2 gate 0 22k
RS source 0 0
.model NMOS1 nmos (level=1 vto=0.7 kp=200u lambda=0.01)
.ac dec 10 10 1Meg
.plot ac db(v(out)/v(in))
.end