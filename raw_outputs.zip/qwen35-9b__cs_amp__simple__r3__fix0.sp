* Common-Source NMOS Amplifier Design
* Target: |Av| = 10 at 1 kHz, VDD = 5V

VDD ddrain 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
M1 drain out gate source NMOS L=1u W=100u
Rs source 0 1k
RL drain out 10k
Cout out 0 1u

.model NMOS nmos (LEVEL=1 VTO=0.7 KP=100u GAMMA=0 PHI=0.4 LAMBDA=0.05 CGSO=20n CGDO=20n CJ=1e-3 MJ=0.5 PB=0.7)
