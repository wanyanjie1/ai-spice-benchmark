* Two-Stage CMOS Operational Amplifier
* VDD = 5V, Gain >= 60dB, Miller Compensated
* Topology: PMOS Diff Pair + NMOS Current Mirror Load (Stage 1)
*          NMOS Common Source + PMOS Current Source Load (Stage 2)

* Supply Voltage
Vdd out_node 0 DC 5

* Device Models
.model NMOS nmos (level=1 vto=-0.4 kp=100u lambda=0.1 cgdo=0 cgd0=0)
.model PMOS pmos (level=1 vto=0.4 kp=50u lambda=0.15 cgdo=0 cgd0=0)

* Bias Network for Tail Current Source (PMOS)
* Generates a voltage to bias the tail current source PMOS gate
Rb1 bias_node 0 1M
Rb2 Vdd bias_node 1M
* Note: With Vdd=5V, this creates ~2.5V at bias_node. 
* For a PMOS tail current (source at Vdd), Vgs = Vg - Vs = 2.5 - 5 = -2.5V.
* Since Vto(PMOS) is +0.4V, |Vgs| > |Vth|, so it turns on.

* Tail Current Source (PMOS) connected to VDD
Mtail PMOS tail_node Vdd bias_node Vdd L=0.18u W=20u model=PMOS

* Differential Input Pair (PMOS)
* Mdiff1: Non-inverting input connected to node 'in'
Mdiff1 PMOS diff_p tail_node in Vdd L=0.18u W=5u model=PMOS
* Mdiff2: Inverting input connected to Ground (AC ground for single-ended test)
Mdiff2 PMOS diff_n tail_node 0 Vdd L=0.18u W=5u model=PMOS

* Active Load for Differential Pair (NMOS Current Mirror)
* Reference branch (Diode connected NMOS) - Gate drives the mirror
Mref_n NMOS ref_gate 0 0 Vdd L=0.18u W=20u model=NMOS
* Mirror branches connected to diff pair drains
* Mload1 connects to drain of Mdiff1 (diff_p)
Mload1 NMOS diff_p out_load_1 ref_gate Vdd L=0.18u W=40u model=NMOS
* Mload2 connects to drain of Mdiff2 (diff_n) - usually tied to output or internal node
Mload2 NMOS diff_n out_load_2 ref_gate Vdd L=0.18u W=40u model=NMOS

* Second Stage: Common Source (NMOS) with PMOS Load
* Input to second stage is the drain of Mdiff1/Mload1 junction (Node: diff_p)
Mcs NMOS out diff_p Vdd Vdd L=0.18u W=2u model=NMOS

* Active Load for Second Stage (PMOS Current Source)
Mcs_load PMOS out Vdd Vdd bias_node L=0.18u W=20u model=PMOS

* Miller Compensation Capacitor
* Connected between Output ('out') and the internal node of the first stage ('diff_p')
Cc diff_p out 5pF

* AC Source at Non-Inverting Input 'in'
Vin in 0 AC 1

* Analysis Command
.ac dec 100 1Hz 1GHz
.end
