* Two-Stage Miller-Compensated CMOS Op Amp
*
* Hand Calculation & Design Derivation:
* 1. Specifications & Process Parameters:
*    VDD = 5.0 V, CL = 1 pF, Cc = 2 pF
*    NMOS: Vto = 0.7 V, KP = 110 uA/V^2, lambda = 0.04 V^-1
*    PMOS: Vto = -0.7 V, KP = 50 uA/V^2, lambda = 0.05 V^-1
*
* 2. Bias & First Stage Design:
*    Iref = 20 uA through NMOS mirror M8 (W/L = 10u/1u).
*    Tail current source M5 (W/L = 10u/1u) mirrors I_tail = 20 uA.
*    Differential pair M1, M2 branch currents: ID1 = ID2 = 10 uA.
*    Diff pair sizing: (W/L)1,2 = 10u/1u.
*    gm1 = sqrt(2 * KP_n * (W/L)1 * ID1) = sqrt(2 * 110u * 10 * 10u) = 148.3 uS.
*    Vov1 = sqrt(2 * 10u / (110u * 10)) = 0.135 V.
*    ro1 = 1 / (lambda_n * ID1) = 1 / (0.04 * 10u) = 2.5 MOhm.
*    PMOS load M3, M4: (W/L)3,4 = 10u/1u, ID3 = ID4 = 10 uA.
*    Vov3 = sqrt(2 * 10u / (50u * 10)) = 0.200 V.
*    ro3 = 1 / (lambda_p * ID3) = 1 / (0.05 * 10u) = 2.0 MOhm.
*    Rout1 = ro1 || ro3 = 2.5M || 2.0M = 1.111 MOhm.
*    Av1 = gm1 * Rout1 = 148.3 uS * 1.111 MOhm = 164.8 V/V (44.3 dB).
*
* 3. Second Stage Design:
*    Current source load M7 (W/L = 50u/1u) mirrors 5 * 20 uA = 100 uA.
*    PMOS common-source driver M6 (W/L = 100u/1u) biased with ID6 = 100 uA.
*    gm6 = sqrt(2 * KP_p * (W/L)6 * ID6) = sqrt(2 * 50u * 100 * 100u) = 1.0 mS.
*    ro6 = 1 / (lambda_p * ID6) = 1 / (0.05 * 100u) = 200 kOhm.
*    ro7 = 1 / (lambda_n * ID7) = 1 / (0.04 * 100u) = 250 kOhm.
*    Rout2 = ro6 || ro7 = 200k || 250k = 111.11 kOhm.
*    Av2 = gm6 * Rout2 = 1.0 mS * 111.11 kOhm = 111.11 V/V (40.9 dB).
*
* 4. Total Gain & Saturation Verification:
*    Total DC open-loop gain Av = Av1 * Av2 = 164.8 * 111.11 = 18,310 V/V (~85.2 dB >= 60 dB spec).
*    Operating voltages: V(tail) = 1.665 V, V(out1) = 4.100 V, V(nbias) = 0.890 V, V(out) = 2.500 V.
*    Vds5 = 1.665 V > Vov5 (0.19 V) -> Saturation confirmed.
*    Vds1,2 = 2.435 V > Vov1,2 (0.135 V) -> Saturation confirmed.
*    Vsd3,4 = 0.900 V > Vov3,4 (0.200 V) -> Saturation confirmed.
*    Vsd6 = 2.500 V > Vov6 (0.200 V) -> Saturation confirmed.
*    Vds7 = 2.500 V > Vov7 (0.190 V) -> Saturation confirmed.

* Models
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05

* Power Supply & Bias Reference
VDD vdd 0 DC 5
Iref vdd nbias DC 20u

* Transistors
M8 nbias nbias 0 0 NMOS1 W=10u L=1u
M5 tail nbias 0 0 NMOS1 W=10u L=1u
M1 out1 in tail 0 NMOS1 W=10u L=1u
M2 n2 inn tail 0 NMOS1 W=10u L=1u
M3 out1 n2 vdd vdd PMOS1 W=10u L=1u
M4 n2 n2 vdd vdd PMOS1 W=10u L=1u
M6 out out1 vdd vdd PMOS1 W=100u L=1u
M7 out nbias 0 0 NMOS1 W=50u L=1u

* Miller Compensation & Load Capacitance
Cc out1 out 2p
CL out 0 1p

* Open-Loop AC Test Bench Network
Vin in 0 DC 2.5 AC 1
L1 out inn 1G
C1 inn 0 1

* Analysis Commands
.op
.ac dec 20 1 100MEG

.end
