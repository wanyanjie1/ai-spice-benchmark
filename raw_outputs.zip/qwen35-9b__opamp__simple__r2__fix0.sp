* Two-Stage CMOS Op-Amp: Differential Pair + Common Source + Miller Compensation
* Technology: 0.18um CMOS (Simplified models for simulation)
* VDD = 5V, Target Gain >= 60dB
* --- DC Supply ---
VDD vdd 0 DC 5V
VGND gnd 0 DC 0V
* --- Bias Current Source (Tail Current) ---
* I_tail = 100uA to ensure good overdrive for input pair
Mtail drain tail gnd VGND L=0.36u W=72u model=nmos
.model nmos NMOS (LEVEL=1 VTO=0.4 KP=100u GAMMA=0.5 LAMBDA=0.05)
* --- Input Differential Pair (NMOS) ---
* Inputs: in+, in- (Non-inverting is 'in')
* W/L ratio chosen for ~200uA branch current per side with 100uA tail? 
* Actually, let's set I_tail = 200uA total to get good swing. 
* Let's adjust Mtail width to get 200uA.
Mtail drain tail gnd VGND L=0.36u W=144u model=nmos
* Input Pair Transistors (NMOS)
* Overdrive Vov ~ 0.2V -> Id = 0.5*Kp*(W/L)*Vov^2 => 100uA = 0.5*100u*(W/L)*0.04 => W/L = 10k? Too high.
* Let's use standard sizing: W=36u, L=0.36u for each input device with 200uA tail current (100uA each).
* Wait, if tail is 200uA, each side gets 100uA.
* Id = 0.5 * Kn * (W/L) * Vov^2. Assume Vov=0.2V. 
* 100u = 0.5 * 100u * (W/L) * 0.04 => 100 = 2 * (W/L) => W/L = 50.
* Let's use L=0.36um, W=18um for each input transistor.
M1 drain out in VGND L=0.36u W=18u model=nmos
M2 drain out in_ tail L=0.36u W=18u model=nmos
* --- Active Load for Input Pair (PMOS Current Mirror) ---
* Tail current source is actually a PMOS current mirror load usually, but here we used NMOS tail? 
* Standard 2-stage: Diff pair (NMOS) with PMOS active load (Current Mirror), then CS stage.
* Let's restructure for standard topology:
* Stage 1: NMOS Diff Pair (M1, M2) loaded by PMOS Current Mirror (M3, M4).
* Stage 2: PMOS Common Source (M5) with NMOS Active Load (M6 - diode connected).
* Correct Topology Setup:
* VDD connected to PMOS loads.
* NMOS Diff Pair at bottom.
* PMOS Current Mirror as active load for diff pair.
* Output of Stage 1 is node X.
* M5 (PMOS) is the second stage CS transistor, gate connected to X.
* M6 (NMOS) is the active load for M5 (diode connected).
* --- Re-defining Devices with Standard Topology ---
* NMOS Input Pair
M1 drain node_x in VGND L=0.36u W=18u model=nmos
M2 drain node_x in_ tail L=0.36u W=18u model=nmos
* PMOS Current Mirror Load (Active Load for Diff Pair)
* M3 and M4 form the mirror. Gate of M3 connected to Drain of M3.
* M3 drain is connected to VDD. Source to node_x? No.
* Standard: M1/M2 sources connect to tail current. Drains connect to drains of M3/M4.
* M3/M4 sources connect to VDD.
* M3 gate connected to M3 drain (node_x). M4 gate connected to M3 gate.
M3 drain node_x in_ tail L=0.36u W=18u model=pmos
M4 drain out node_x L=0.36u W=18u model=pmos
* Wait, the naming above is confusing. Let's do it cleanly.
* Nodes: VDD (5V), GND (0V).
* Input: 'in' (non-inverting), 'in_' (inverting).
* Output: 'out'.
* Internal node between stages: 'node_x'.
* --- NMOS Differential Pair ---
M1 drain node_x in VGND L=0.36u W=18u model=nmos
M2 drain node_x in_ tail L=0.36u W=18u model=nmos
* --- PMOS Current Mirror Load (Active Load for Stage 1) ---
* M3: Diode connected, connects VDD to node_x.
* M4: Mirrors M3, connects VDD to out? No, M4 is the load for the second stage usually? 
* Correction: In a standard 2-stage opamp:
* Stage 1 Output is at the drain of M1/M2 and M3/M4. Let's call this node 'node_x'.
* But usually, the current mirror load makes the output of stage 1 high impedance.
* So M1/M2 drains connect to M3/M4 drains.
* M3 gate connected to M3 drain (node_x). M4 gate connected to M3 gate.
* M4 drain is the output of Stage 1? No, usually the output of Stage 1 is taken from the drain of M4? 
* Actually, the standard topology has the output of Stage 1 at the drain of M4 (which is also the source of M5).
* Let's refine:
* M1, M2: NMOS diff pair. Sources connected to Tail Current Source (M_tail).
* M3, M4: PMOS current mirror. Sources to VDD.
* M1 drain connects to M3 drain.
* M2 drain connects to M4 drain.
* M3 gate connects to M3 drain.
* M4 gate connects to M3 gate.
* Output of Stage 1 is taken at the drain of M4 (node 'node_x').
* Wait, if M1/M2 are matched and M3/M4 are matched, the DC voltage at node_x is determined by the current.
* The second stage (M5) takes input from node_x.
* Let's fix the schematic logic:
* Tail Current: M_tail (NMOS) sinking current from sources of M1/M2.
* Active Load: M3 (PMOS diode connected), M4 (PMOS mirror).
* M1 drain -> M3 drain -> Node A.
* M2 drain -> M4 drain -> Node B (Output of Stage 1).
* Wait, usually the current mirror is used to convert differential current to single-ended voltage at one node.
* If M1/M2 are diff pair, and M3/M4 are PMOS mirror:
* M1 drain connects to M3 drain.
* M2 drain connects to M4 drain.
* M3 gate connected to M3 drain.
* M4 gate connected to M3 gate.
* The output of the first stage is taken from the drain of M4 (Node B).
* Why? Because M1/M2 current difference flows into M3/M4. 
* Actually, standard design: 
* M1 drain connects to M3 drain. M2 drain connects to M4 drain.
* M3 gate connected to M3 drain. M4 gate connected to M3 gate.
* The output of stage 1 is the node where M4 drain is. 
* But wait, if M1 and M2 are symmetric, and input is differential, the current in M1 increases, M2 decreases.
* Current in M3 (load for M1) increases? No, M3 is diode connected.
* Let's assume standard: 
* M1 drain -> Node X. M2 drain -> Node Y.
* M3 (PMOS) source VDD, drain Node X, gate Node X.
* M4 (PMOS) source VDD, drain Node Y, gate Node X.
* This creates a current mirror load. The output of stage 1 is Node Y.
* But usually, we want high gain. 
* Let's simplify: 
* M1, M2: NMOS diff pair. Sources to Tail (M_tail).
* M3, M4: PMOS current mirror.
* M1 drain connects to M3 drain.
* M2 drain connects to M4 drain.
* M3 gate connected to M3 drain.
* M4 gate connected to M3 gate.
* Output of Stage 1 is taken at the drain of M4 (Node 'node_x').
* Wait, if M1 and M2 are matched, and we apply differential signal, the current in M1 changes by +delta, M2 by -delta.
* The voltage at M3 drain (Node X) will change slightly due to finite output resistance, but M4 is diode connected? No, M3 is diode connected.
* If M3 is diode connected, its gate is tied to its drain. 
* Then M4 gate is tied to M3 gate.
* The current in M4 follows M3.
* The output voltage at M4 drain (Node Y) is VDD - Vsg(M4).
* This is the standard high-gain configuration.
* --- Second Stage (Common Source) ---
* M5: PMOS Common Source. Gate connected to 'node_x' (output of stage 1). Drain to 'out'. Source to VDD? No, source to VDD for PMOS CS? 
* Wait, if M5 is PMOS, source should be at VDD. Drain at 'out'.
* Active Load for M5: M6 (NMOS) diode connected.
* M6 drain and gate connected to 'out'. Source to GND.
* So M5 (PMOS) and M6 (NMOS) form the second stage amplifier.
* --- Biasing ---
* We need bias voltages for gates of M1, M2, M3, M4, M5, M6, M_tail.
* Since this is a netlist without .control, we must define DC operating points via initial conditions or just rely on the circuit to find them if we provide reasonable guesses? 
* SPICE needs DC convergence. We can use VDC sources for bias voltages calculated roughly.
* Or, we can assume simple biasing:
* Tail current M_tail: Set W/L to get 200uA with VGS approx 0.8V (for NMOS).
* Let's calculate approximate biases for 5V supply.
* VDD = 5V.
* M_tail (NMOS): Source GND. Need VGS ~ 0.8V. Gate bias VB1 = 0.8V.
* M1, M2 (NMOS): Need VDSAT ~ 0.2V. 
* M3, M4 (PMOS): Need VSG ~ 0.8V. Source VDD. Gate bias VB2 = 5 - 0.8 = 4.2V.
* M5 (PMOS CS): Needs to be in saturation. VSD > VSG - |VTP|. 
* M6 (NMOS Load): Diode connected. VGS ~ 0.7V. Gate bias VB3 = 0.7V.
* M4 drain (node_x) needs to be high enough for M5 to saturate.
* Let's set specific DC voltage sources for gates to ensure convergence and correct bias.
* --- Bias Voltage Sources ---
* Tail Current Bias (M_tail gate): VB_tail
VB_tail tail_gate 0 DC 0.8V
* Input Pair Gates: Need to be biased around mid-rail? 
* Actually, M1/M2 sources are at Vtail_drain. 
* Let's set M1/M2 gates to a common mode voltage. 
* If Tail current is 200uA, and M1/M2 share it, each gets 100uA.
* VGS_nmos for 100uA with W=18u, L=0.36u (Kn=100u): 
* Id = 0.5 * 100u * (18/0.36) * (Vgs-0.4)^2
* 100u = 50u * 50 * (Vov)^2 => 100u = 2500u * Vov^2 => Vov^2 = 0.04 => Vov = 0.2V.
* So VGS = 0.6V.
* Source voltage of M1/M2 = VG - VGS = VB_in - 0.6V.
* Tail current M_tail: Id = 200uA. 
* M_tail W=144u, L=0.36u. Kn=100u.
* 200u = 0.5 * 100u * (144/0.36) * Vov^2 => 200u = 20000u * Vov^2 => Vov = sqrt(0.01) = 0.1V.
* VGS_tail = 0.5V.
* So Source of M1/M2 is at 0.5V.
* Therefore, Gate of M1/M2 (VB_in) should be 0.6V + 0.5V = 1.1V? 
* Wait, if M_tail source is GND, VGS_tail = VG_tail - 0 = 0.5V. So VG_tail = 0.5V.
* Then Source of M1/M2 is at 0.5V.
* To get Vov=0.2V for M1/M2 (100uA each), VGS_M1 = 0.6V.
* So Gate of M1/M2 = Source + VGS = 0.5 + 0.6 = 1.1V.
* Let's set VB_in = 1.1V.
* PMOS Loads (M3, M4):
* Need to sink 200uA total? No, the current from M1/M2 goes into M3/M4.
* Total current from diff pair is 200uA. 
* In a current mirror load, the current in M3 equals current in M4 (ideally).
* But M1 and M2 currents are differential. 
* DC: M1 and M2 carry 100uA each.
* M3 carries 100uA (from M1 side? No, M3 is connected to M1 drain).
* Wait, standard topology: M1 drain connects to M3 drain. M2 drain connects to M4 drain.
* DC Current in M1 = 100uA. So M3 must carry 100uA.
* M3 is diode connected. VSG_M3 determined by Id=100uA.
* W/L for PMOS: Let's use same ratio as NMOS for simplicity? Or optimize.
* Let's use W=18u, L=0.36u for PMOS too (Kp approx 50u usually, but let's assume Kp=100u for symmetry in this simplified model).
* If Kp=100u, then for Id=100uA, Vov = 0.2V.
* VSG = 0.4 + 0.2 = 0.6V.
* Source of M3/M4 is VDD (5V).
* Gate of M3 (and M4) = 5 - 0.6 = 4.4V.
* Let's set VB_load = 4.4V.
* Second Stage (M5, M6):
* M5 (PMOS CS): Needs to carry the current from M4? 
* Wait, in the standard 2-stage opamp, the output of stage 1 is at the drain of M4.
* The current in M4 is roughly equal to the tail current (200uA) because M3 and M4 form a mirror carrying the total tail current? 
* No. In a differential pair with active load:
* Id(M1) + Id(M2) = I_tail = 200uA.
* If balanced, Id(M1)=Id(M2)=100uA.
* M3 carries Id(M1). M4 carries Id(M2).
* So both M3 and M4 carry 100uA DC.
* The output of stage 1 is at the drain of M4 (node_x).
* Current in M4 is 100uA.
* Now, M5 (PMOS CS) takes input from node_x.
* M5 must carry the same current as M4 to keep node_x stable? 
* No, M5 is the second stage transistor. Its drain connects to 'out'.
* M6 (NMOS diode connected) loads M5.
* The DC current in the second stage branch (M5 + M6) must match the current coming from M4?
* Actually, node_x is the output of stage 1. It drives the gate of M5.