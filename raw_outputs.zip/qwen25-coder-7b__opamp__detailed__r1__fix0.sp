* Two-stage Miller-compensated CMOS op amp design
* NMOS differential pair with PMOS current-mirror load
* NMOS tail current source biased by a current mirror (e.g. 20uA reference)
* PMOS common-source second stage with NMOS current-source load
* Miller capacitor Cc (~2pF) from first-stage output to 'out'
* NMOS transistors
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
* PMOS transistors
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05
* NMOS differential pair
M1 in1 inn out1 NMOS1 W=10u L=1u
M2 in2 inn out2 NMOS1 W=10u L=1u
* PMOS current-mirror load
M3 out1 out2 out3 PMOS1 W=20u L=1u
M4 out1 out2 out4 PMOS1 W=20u L=1u
* NMOS tail current source
M5 out3 tail tail NMOS1 W=1u L=1u
M6 out4 tail tail NMOS1 W=1u L=1u
* PMOS common-source second stage
M7 tail out out PMOS1 W=20u L=1u
* Miller capacitor
Cc out out 0 2p
* AC test bench
V1 in 0 DC 2.5 AC 1
L1 out inn 1G
C1 inn 0 1
* Output node
.out out