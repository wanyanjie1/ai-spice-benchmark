* Common-source NMOS Amplifier Design

* Define NMOS device model
.model NMOS NMOS L=1u W=10u KP=100u

* Define supply voltage
VDD 1 0 DC 5V

* Define input AC source
Vin 1 0 AC 1V

* Define output node
Vout 2 0

* Define NMOS transistor
M1 2 1 0 0 NMOS

* Define load resistor
Rload 2 0 1k

* Define ground
0 0

* Define AC analysis
.tran 1ms 10ms
.ac dec 10 1Hz 10kHz

* Define output voltage measurement
.print ac v(out)
