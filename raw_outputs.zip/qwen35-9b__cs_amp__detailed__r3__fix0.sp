* Common-Source NMOS Amplifier Design
* Specs: |Av| = 10, VDD = 5V, f = 1kHz, No external load
* Model: NMOS level=1, vto=0.7, kp=200u, lambda=0.01
* --- Hand Calculation & Component Selection Comments ---
* 1. Choose ID and VGS to set bias point in saturation.
*    Let's target VDS = 2.5V (mid-supply) for maximum swing.
*    Target gm = |Av| / RD. We need to pick RD first or iterate.
*    Let's choose a standard RD = 1kOhm. Then required gm = 10/1k = 0.01 A/V = 10mA/V.
*    Formula: gm = 2 * ID / (VGS - VTO) => 10mA/V = 2 * ID / (VGS - 0.7)
*    Let's choose VGS = 1.5V (reasonable overdrive).
*    Then 10mA/V = 2 * ID / (1.5 - 0.7) => 10mA/V = 2 * ID / 0.8 => ID = 4mA.
*    Check VDS: VDS = VDD - ID*RD = 5V - 4mA*1kOhm = 1V.
*    Wait, VDS (1V) must be > VGS-VTO (1.5-0.7=0.8V). 1V > 0.8V. OK, in saturation.
*    However, let's re-evaluate RD to ensure better headroom or adjust ID.
*    Alternative: Let's aim for VDS = 2.5V.
*    If VDS = 2.5V and VDD=5V, then voltage drop across RD is 2.5V.
*    If we keep ID = 4mA, then RD = 2.5V / 4mA = 625 Ohms.
*    New gm check: gm = 2*ID/(VGS-VTO) = 8mA/0.8V = 10 mS.
*    Av = -gm * (RD || ro). ro = 1/(lambda*ID) = 1/(0.01*0.004) = 25kOhm.
*    RD || ro = 625 || 25000 ≈ 607 Ohms.
*    Av = -10mS * 607Ohm ≈ -6.07. This is too low (we need 10).
*    We need higher gm or higher effective resistance.
*    Let's try increasing ID to increase gm and adjust RD.
*    Try ID = 5mA. VGS needs to be calculated for saturation current equation:
*      ID = 0.5 * kp * (VGS-VTO)^2 => 5mA = 0.5 * 200u * (Vov)^2
*      5e-3 = 100e-6 * Vov^2 => Vov^2 = 50 => Vov = 7.07V. Too high!
*    The model kp=200u is quite large for a small signal amp with 5V supply if we want high ID.
*    Let's re-read model: kp=200u (A/V^2). Usually W/L is implicit or kp includes it.
*    If kp=200u, then for Vov=0.5V, ID = 0.5 * 200u * 0.25 = 25uA. Very small.
*    To get ID=1mA with Vov=0.5V: 1e-3 = 0.5 * kp_eff * 0.25 => kp_eff = 8mA/V^2 = 8000u.
*    My previous assumption of ID=4mA with VGS=1.5V (Vov=0.8) gave:
*      ID_calc = 0.5 * 200u * (0.8)^2 = 64uA. This is NOT 4mA.
*    I made a math error in the thought process above regarding the model parameters vs desired current.
*    Let's restart the calculation with the given model strictly:
*      Model: kp=200u, vto=0.7.
*      Let's pick VGS = 1.5V => Vov = 0.8V.
*      ID = 0.5 * 200e-6 * (0.8)^2 = 64e-6 A = 64 uA.
*      This is a very small current. Let's stick with this for low power, or increase VGS?
*      If we want higher gain, we need higher gm. gm = kp * Vov (for level 1).
*      gm = 200e-6 * 0.8 = 160 uA/V = 0.16 mS.
*      To get |Av| = 10, we need RD such that gm*RD ≈ 10 (ignoring ro for a moment).
*      RD = 10 / 0.16mS = 62.5 kOhms.
*      Let's check VDS with RD=62.5k and ID=64uA:
*      Vdrop_RD = 64e-6 * 62500 = 4V.
*      VDS = 5V - 4V = 1V.
*      Saturation condition: VDS > Vov => 1V > 0.8V. Holds.
*      Now check ro: ro = 1 / (lambda * ID) = 1 / (0.01 * 64e-6) = 1 / 6.4e-7 = 1.56 MOhms.
*      Effective R_D = RD || ro = 62.5k || 1.56M ≈ 59.3 kOhms.
*      Av = -gm * (RD||ro) = -0.16mS * 59.3k = -9.49. Close to 10.
*      Let's tweak VGS slightly to hit exactly 10? Or just accept ~9.5.
*      Let's try VGS = 1.55V => Vov = 0.85V.
*      ID = 0.5 * 200e-6 * (0.85)^2 = 72.25 uA.
*      gm = 200e-6 * 0.85 = 170 uS = 0.17 mS.
*      Vdrop_RD needed for Av=10: RD_eff = 10 / 0.17mS = 58.8 kOhms.
*      Let's set RD = 60k (standard value).
*      Vdrop_RD = 72.25uA * 60k = 4.335V.
*      VDS = 5 - 4.335 = 0.665V.
*      Saturation check: VDS (0.665) > Vov (0.85)? NO. 0.665 < 0.85.
*      The transistor will be in triode region, gain drops significantly.
*    Conclusion: With kp=200u and VDD=5V, we cannot get high current AND high gain easily while staying in saturation if we rely on large RD.
*    Wait, the constraint is |Av|=10.
*    If we lower ID, gm lowers, so RD must increase. But increasing RD drops VDS.
*    There is a trade-off.
*    Let's try to maximize Vov to get high gm? No, higher Vov means higher VGS, but saturation limit tightens.
*    Actually, let's look at the "no external load" spec.
*    Maybe I should use a smaller RD and accept lower gain? No, spec says 10.
*    Let's re-calculate carefully.
*    Equation: Av = - (kp * Vov) * (RD || ro).
*    We need |Av| = 10.
*    Let's assume ro is large enough initially to ignore it for sizing, then verify.
*    10 ≈ kp * Vov * RD => RD = 10 / (kp * Vov).
*    Also VDS = VDD - ID * RD > Vov.
*    Substitute ID = 0.5 * kp * Vov^2 and RD = 10/(kp*Vov):
*    VDS = VDD - (0.5 * kp * Vov^2) * (10 / (kp * Vov))
*    VDS = VDD - 5 * Vov.
*    Condition: VDS > Vov => VDD - 5*Vov > Vov => VDD > 6*Vov => Vov < VDD/6.
*    With VDD=5V, max Vov = 0.833V.
*    If we pick Vov = 0.8V (as calculated before):
*      RD = 10 / (200e-6 * 0.8) = 10 / 0.00016 = 62,500 Ohms = 62.5k.
*      VDS = 5 - 5*0.8 = 1V.
*      Check saturation: VDS (1V) > Vov (0.8V). OK.
*      Now include ro effect.
*      ID = 0.5 * 200e-6 * 0.8^2 = 64 uA.
*      ro = 1 / (0.01 * 64e-6) = 1.56 MOhm.
*      R_total = 62.5k || 1.56M = 59.3 kOhm.
*      Av = - gm * R_total = - (200e-6 * 0.8) * 59.3e3 = -0.16mS * 59.3k = -9.49.
*    This is very close to 10. To get exactly 10, we need slightly higher gm or lower ro impact (impossible).
*    We can increase Vov slightly? If Vov=0.82:
*      RD = 10 / (200e-6 * 0.82) = 60.97k.
*      VDS = 5 - 5*0.82 = 0.9V.
*      Saturation: 0.9 > 0.82. OK.
*      ID = 0.5 * 200e-6 * 0.82^2 = 67.28 uA.
*      gm = 164.5 uS.
*      ro = 1 / (0.01 * 67.28e-6) = 1.48 MOhm.
*      R_total = 60.97k || 1.48M = 58.3 kOhm.
*      Av = -164.5uS * 58.3k = -9.59. Still dropping due to ro.
*    It seems with lambda=0.01, ro is not infinite enough to reach exactly 10 with these constraints without violating saturation or using unrealistic components.
*    However, the prompt asks to "choose RD so that gm*RD ~= 10". The "~=" implies approximation is acceptable given the model limitations (ro loading).
*    Let's stick with VGS = 1.5V (Vov=0.8V) and RD = 62k (standard value close to 62.5k).
*    Or use exact calculated values for simulation accuracy: RD = 62.5k.
*    Gate Divider: Need VG = VGS + VS = 1.5V + 0V = 1.5V.
*    R1 (top) and R2 (bottom). Let's pick R2 = 100k, then R1 = (5-1.5)/100k * 100k? No.
*    Divider ratio: Vg = 5 * R2 / (R1+R2) = 1.5 => R2/(R1+R2) = 0.3.
*    Let R2 = 30k, R1 = 70k. Or use larger resistors to minimize bias current?
*    Input impedance is high anyway. Let's use R1=180k, R2=47k (standard values approximating ratio).
*    Exact: R2 = 30k, R1 = 70k. Total 100k. Current ~50uA. Acceptable.
*    Let's use R1=70k, R2=30k.
* --- Circuit Definition ---
VDD VDD 0 DC 5
VIN in 0 AC 1
Cin in gate 10uF
M1 drain gate source 0 NMOS1 L=1u W=1u
RD drain VDD
R1 VDD gate
R2 gate 0
RS source 0
Vout out drain
* --- Model Definition ---
.model NMOS1 nmos (level=1 vto=0.7 kp=200u lambda=0.01)
* --- Bias Resistors Calculation ---
* Target VGS = 1.5V. VG = 1.5V.
* Divider: R2/(R1+R2) = 1.5/5 = 0.3.
* Choose R2 = 30k, R1 = 70k.
* --- Netlist Construction ---
VDD VDD 0 DC 5
VIN in 0 AC 1
Cin in gate 10uF
M1 drain gate source 0 NMOS1 L=1u W=1u
RD drain VDD 62.5k
R1 VDD gate 70k
R2 gate 0 30k
RS source 0 0
* --- Output Node ---
* out is connected to drain of M1
.out
.end