* First-Order Passive RC Low-Pass Filter Design
* Target Specifications:
* - Cutoff frequency (fc) = 1 kHz
* - Passband gain = 0 dB
*
* Hand Calculations:
* Formula: fc = 1 / (2 * pi * R * C)
* Pick standard capacitor: C = 100 nF (1e-7 F)
* Compute R:
* R = 1 / (2 * pi * fc * C)
* R = 1 / (2 * pi * 1000 * 100e-9)
* R = 1 / (6.2831853e-4) = 1591.55 ohms (1.59155 kOhm)

* Circuit Topology
V1 in 0 DC 0 AC 1
R1 in out 1.59155k
C1 out 0 100n

* AC Analysis Simulation Command (10 Hz to 100 kHz)
.ac dec 20 10 100k

.end
