* Two-Stage Miller-Compensated CMOS Operational Amplifier
* Hand Calculations:
* -----------------------------------------------------------------------------
* Technology Parameters:
*   NMOS: Vtn = 0.7V, Kp_n = 110u A/V^2, lambda_n = 0.04 V^-1
*   PMOS: Vtp = -0.7V, Kp_p = 50u A/V^2, lambda_p = 0.05 V^-1
* Supply: VDD = 5V, VSS = 0V
*
* 1. Bias Circuit (M8 & Iref = 20uA):
*    (W/L)8 = 10u / 2u = 5
*    ID8 = 20uA = 0.5 * Kp_n * (W/L)8 * (VGS8 - Vtn)^2
*    20u = 0.5 * 110u * 5 * Vov8^2  =>  Vov8 = sqrt(20u / 275u) = 0.27 V
*    VGS8 = Vbias_n = 0.7 + 0.27 = 0.97 V
*
* 2. First Stage Tail & Diff Pair (M5, M1, M2, M3, M4):
*    Tail Current Source M5: (W/L)5 = 10u / 2u = 5 => ID5 = 20uA
*    Diff Pair M1, M2: ID1 = ID2 = 10uA, (W/L)1,2 = 20u / 2u = 10
*    gm1,2 = sqrt(2 * Kp_n * (W/L)1 * ID1) = sqrt(2 * 110u * 10 * 10u) = 148.3 uS
*    Vov1,2 = sqrt(2 * 10u / (110u * 10)) = 0.135 V
*    Vtail = Vin - VGS1 = 2.5 - (0.7 + 0.135) = 1.665 V (M5 is saturated: VDS5 = 1.665V > Vov5 = 0.27V)
*
*    PMOS Active Load M3, M4: (W/L)3,4 = 20u / 2u = 10
*    ID3 = ID4 = 10uA => Vov3,4 = sqrt(2 * 10u / (50u * 10)) = 0.20 V
*    VGS3,4 = -0.7 - 0.20 = -0.90 V => Vout1 = VDD - 0.90 = 4.10 V
*
*    First Stage Output Resistance:
*    ro2 = 1 / (lambda_n * ID2) = 1 / (0.04 * 10u) = 2.5 Mohm
*    ro4 = 1 / (lambda_p * ID4) = 1 / (0.05 * 10u) = 2.0 Mohm
*    Ro1 = ro2 || ro4 = 1.11 Mohm
*    Av1 = gm1 * Ro1 = 148.3u * 1.11M = 164.6 V/V (44.3 dB)
*
* 3. Second Stage (M6, M7):
*    NMOS Load M7: (W/L)7 = 50u / 2u = 25 => ID7 = 5 * ID8 = 100uA
*    PMOS Driver M6: Gate connected to Vout1 (4.1V => VSG6 = 0.9V => Vov6 = 0.2V)
*    ID6 = 100uA = 0.5 * Kp_p * (W/L)6 * Vov6^2 => (W/L)6 = 100u / (0.5 * 50u * 0.04) = 100
*    (W/L)6 = 200u / 2u = 100
*    gm6 = sqrt(2 * 50u * 100 * 100u) = 1.0 mS
*
*    Second Stage Output Resistance:
*    ro6 = 1 / (lambda_p * ID6) = 1 / (0.05 * 100u) = 200 kohm
*    ro7 = 1 / (lambda_n * ID7) = 1 / (0.04 * 100u) = 250 kohm
*    Ro2 = ro6 || ro7 = 111.1 kohm
*    Av2 = gm6 * Ro2 = 1.0m * 111.1k = 111.1 V/V (40.9 dB)
*
* 4. Total DC Gain & Saturation Verification:
*    Av = Av1 * Av2 = 164.6 * 111.1 = 18287 V/V = 85.2 dB (Spec: >= 60 dB)
*    All transistors operating in saturation region:
*      M1, M2: VDS = 4.10 - 1.665 = 2.435V > Vov1 (0.135V) -> Saturated
*      M3, M4: VSD = 5 - 4.10 = 0.90V > Vov3 (0.20V) -> Saturated
*      M5: VDS = 1.665V > Vov5 (0.27V) -> Saturated
*      M6: VSD = 5 - 2.50 = 2.50V > Vov6 (0.20V) -> Saturated
*      M7: VDS = 2.50V > Vov7 (0.27V) -> Saturated
*      M8: VDS = VGS = 0.97V > Vov8 (0.27V) -> Saturated
* -----------------------------------------------------------------------------

* Model Definitions
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05

* Power Supply & Reference Current
Vdd vdd 0 DC 5
Iref vdd vbias_n DC 20u

* Bias Mirror Transistor
M8 vbias_n vbias_n 0 0 NMOS1 W=10u L=2u

* First Stage: Differential Pair with PMOS Mirror Load
M1 out1_n in tail 0 NMOS1 W=20u L=2u
M2 out1 inn tail 0 NMOS1 W=20u L=2u
M3 out1_n out1_n vdd vdd PMOS1 W=20u L=2u
M4 out1 out1_n vdd vdd PMOS1 W=20u L=2u
M5 tail vbias_n 0 0 NMOS1 W=10u L=2u

* Second Stage: PMOS Common-Source with NMOS Current Load
M6 out out1 vdd vdd PMOS1 W=200u L=2u
M7 out vbias_n 0 0 NMOS1 W=50u L=2u

* Miller Compensation & Load Capacitance
Cc out1 out 2p
CL out 0 1p

* Open-Loop AC Testbench with DC Feedback
Vin in 0 DC 2.5 AC 1
L1 out inn 1G
C1 inn 0 1

.op
.ac dec 20 1 100Meg

.end
