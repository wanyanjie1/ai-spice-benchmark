* Single-Stage Common-Source NMOS Amplifier
*
* Hand Calculation:
* 1. Choose VGS = 1.1 V and VTO = 0.7 V => Overdrive voltage Vov = VGS - VTO = 0.4 V.
* 2. Transistor sizing: Choose W = 10u, L = 1u (W/L = 10).
* 3. Drain Current: ID = 0.5 * KP * (W/L) * Vov^2 
*                       = 0.5 * 200u * 10 * (0.4)^2 = 160 uA.
* 4. Transconductance: gm = 2 * ID / (VGS - VTO) 
*                         = 2 * 160u / 0.4 = 0.8 mS.
* 5. Output Resistance: ro = 1 / (lambda * ID) = 1 / (0.01 * 160u) = 625 kOhm.
* 6. Select RD for Gain |Av| = 10:
*    |Av| = gm * (RD || ro) = 10
*    RD || ro = 10 / 0.8 mS = 12.5 kOhm
*    RD = (12.5k * 625k) / (625k - 12.5k) = 12.75 kOhm.
* 7. Check Saturation: VDS = VDD - ID * RD = 5V - (160uA * 12.75kOhm) = 2.96 V.
*    Since VDS (2.96 V) > VGS - VTO (0.4 V), the transistor is safely in saturation.
* 8. Resistor-divider gate bias:
*    VG = VDD * R2 / (R1 + R2) = 1.1 V
*    Choose R1 = 780 kOhm, R2 = 220 kOhm (VG = 5 * 220k / 1000k = 1.1 V).

* Power Supply
VDD vdd 0 DC 5

* Input Signal Source
V1 in 0 DC 0 AC 1

* Gate Bias Resistors & Input Coupling Capacitor
R1 vdd g 780k
R2 g 0 220k
Cin in g 10u

* MOSFET Transistor
M1 out g 0 0 NMOS1 W=10u L=1u

* Drain Load Resistor
RD vdd out 12.75k

* Device Model Definition
.model NMOS1 nmos level=1 vto=0.7 kp=200u lambda=0.01

* Simulation Commands
.op
.ac dec 10 100 10k

.end
