* Common-Source NMOS Amplifier Design
* Target: Gain = 10 (20 dB), f = 1 kHz, VDD = 5V
VDD vdd 0 DC 5
Vin in 0 AC 1
Rsig in gate 1k
M1 drain gate source 0 NMOS
RD drain out 1k
RS source 0 100k
Cout out 0 1uF
Cin in 0 1uF
* NMOS Model Definition (W/L = 10um/1um for reasonable gain)
* Fixed model name 'NMOS' to match the device instance M1
.model NMOS nmos (LEVEL=1 VTO=0.7 KP=110u GAMMA=0.5 LAMBDA=0.02 CGSO=2n CGDO=2n CJ=4f CGBO=2f)
* AC Analysis Setup
.AC DEC 100 10Hz 1MHz
.END