Here is the corrected SPICE netlist:
* Two-stage Miller-compensated CMOS op amp design
* Open-loop gain >= 60 dB at low frequency, VDD = 5 V, CL = 1 pF
* NMOS differential pair with PMOS current-mirror load
* NMOS tail current source biased by a current mirror (e.g. 20uA reference)
* PMOS common-source second stage with NMOS current-source load
* Miller capacitor Cc (~2pF) from first-stage output to 'out'
* NMOS models
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
* PMOS models
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05
* Transistor dimensions
* NMOS transistors
W1 = 10u L1 = 1u
W2 = 10u L2 = 1u
W3 = 10u L3 = 1u
W4 = 10u L4 = 1u
W5 = 10u L5 = 1u
W6 = 10u L6 = 1u
W7 = 10u L7 = 1u
W8 = 10u L8 = 1u
W9 = 10u L9 = 1u
W10 = 10u L10 = 1u
W11 = 10u L11 = 1u
W12 = 10u L12 = 1u
W13 = 10u L13 = 1u
W14 = 10u L14 = 1u
W15 = 10u L15 = 1u
W16 = 10u L16 = 1u
W17 = 10u L17 = 1u
W18 = 10u L18 = 1u
W19 = 10u L19 = 1u
W20 = 10u L20 = 1u
* PMOS transistors
W21 = 10u L21 = 1u
W22 = 10u L22 = 1u
W23 = 10u L23 = 1u
W24 = 10u L24 = 1u
W25 = 10u L25 = 1u
W26 = 10u L26 = 1u
W27 = 10u L27 = 1u
W28 = 10u L28 = 1u
W29 = 10u L29 = 1u
W30 = 10u L30 = 1u
W31 = 10u L31 = 1u
W32 = 10u L32 = 1u
W33 = 10u L33 = 1u
W34 = 10u L34 = 1u
W35 = 10u L35 = 1u
W36 = 10u L36 = 1u
W37 = 10u L37 = 1u
W38 = 10u L38 = 1u
W39 = 10u L39 = 1u
W40 = 10u L40 = 1u
* NMOS tail current source
Vtail 1 0 DC 20u
* NMOS differential pair
M1 2 3 1 0 NMOS1
M2 4 5 1 0 NMOS1
M3 2 3 6 0 NMOS1
M4 4 5 6 0 NMOS1
* PMOS current-mirror load
M5 7 8 2 3 PMOS1
M6 9 10 4 5 PMOS1
M7 7 8 9 10 PMOS1
M8 9 10 11 12 PMOS1
* PMOS common-source second stage
M9 13 14 15 0 PMOS1
M10 16 17 15 0 PMOS1
M11 13 14 18 0 PMOS1
M12 16 17 18 0 PMOS1
* Miller capacitor
Cc 14 19 2p
* AC test bench
Vin 1 0 AC 1
L1 1 2 1G
C1 2 0 1F
* Output node
.out 19