* First-order Passive RC Low-Pass Filter Design
* Spec: fc = 1 kHz, Passband Gain = 0 dB
* Topology: V1(in) -> R -> out -> C -> GND
* Calculation: fc = 1/(2*pi*R*C) => R = 1/(2*pi*fc*C)
* Given C = 100nF (Standard Value), fc = 1000 Hz
* R = 1 / (2 * pi * 1000 * 100e-9) = 1591.549... Ohms
* Selected Standard Resistor: 1.6kOhm (Closest E12 value, fc_actual ~ 995 Hz)
V1 in 0 AC 1
R1 in out 1.6k
C1 out 0 100nF
.model V1 voltage (level=1)
.model R1 resistor (rvalue=1.6k)
.model C1 capacitor (cvalue=100nF)
.ac dec 10 10 1Meg
.plot ac db(v(out)) db(v(in))
.end