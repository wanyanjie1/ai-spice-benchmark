.model NMOS NMOS L=1u W=10u
VDD 1 0 DC 5V
VSS 2 0 DC 0V
VDDout 3 0 DC 5V
VSSout 4 0 DC 0V
Rin 1 in 10k
Rout out 10k
M1 in 2 out 3 NMOS L=1u W=10u
M2 out 4 in NMOS L=1u W=10u
.tran 1ms 10ms
.end