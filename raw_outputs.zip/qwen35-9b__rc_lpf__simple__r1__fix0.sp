* First-order Passive RC Low-Pass Filter
* Cutoff Frequency: 1 kHz
* R = 1/(2*pi*f_c*C) -> Let C=1uF, then R approx 159.15 Ohms
V1 in 0 AC 1
R1 in out 159.1549
C1 out 0 1u
.model R1 res (rseries=0)
.model C1 cap (c=1u)
.ac dec 100 10 1Meg
.plot ac v(out)
.end