* Two-Stage CMOS Op-Amp: Differential Pair + Common Source + Miller Compensation
* VDD = 5V, Target Gain >= 60dB

* Technology Parameters (Simplified 180nm-like for simulation)
.param VDD=5.0
.param VSS=0.0
.param W_L=0.5u
.param L=0.18u

* Device Models
.model NMOS nmos (level=1 vto=0.4 kp=120u lambda=0.1 cgdo=0 cgd0=0)
.model PMOS pmos (level=1 vto=-0.4 kp=60u lambda=0.15 cgdo=0 cgd0=0)

* Circuit Nodes
* Input: in (non-inverting), out (output)
* Internal nodes: diff_p, diff_n (differential pair drains), cascode_tail, miller_node

* Bias Current Source (Tail Current for Diff Pair)
Mtail pmos VSS tail_node VDD VDD L={L} W=20u model=pmos

* Differential Input Pair (NMOS)
* Inputs: in+, in- (connected to 'in' and ground for single-ended testing, or differential if needed)
* Here we connect 'in' to the non-inverting input (+) and ground to (-) for AC analysis as per prompt.
Mdiff1 nmos in diff_p tail_node VDD L={L} W=5u model=nmos
Mdiff2 nmos in_ diff_n tail_node VDD L={L} W=5u model=nmos

* Active Load for Diff Pair (PMOS Current Mirror)
* We need a current mirror load. Let's use a simple active load configuration.
* To simplify the netlist to a standard 2-stage topology without complex biasing networks that require extra nodes not requested:
* We will assume a bias voltage is available or generate it via a resistor/capacitor network if strictly necessary, 
* but for a robust SPICE netlist, we usually define a bias node. However, the prompt asks for specific nodes.
* Let's create a self-biasing structure or assume standard bias voltages are provided by external sources not shown?
* Standard practice: Use a PMOS current mirror load. We need a reference branch.
* To keep it minimal and functional in one block, we will add a simple bias generator using resistors if needed, 
* but MOSFETs require Vgs. Let's assume a standard bias setup where the top of the diff pair is connected to VDD via a PMOS current source mirror.
* We need a reference current source and its mirror.

* Reference Current Branch (PMOS)
Mref_p pmos VDD ref_node VDD VDD L={L} W=10u model=pmos
Rbias VDD ref_node 1k

* Mirror Load for Diff Pair (PMOS)
* Connects to diff_p and diff_n. We need a mirror pair.
Mload1 pmos diff_p out_load_1 VDD VDD L={L} W=20u model=pmos
Mload2 pmos diff_n out_load_2 VDD VDD L={L} W=20u model=pmos

* Second Stage: Common Source (NMOS) with PMOS Active Load
* Input to second stage is the drain of the first stage (diff_p or diff_n). 
* Let's take diff_p as the input to the second stage.
Mcs_in nmos out_load_1 cascode_node VDD L={L} W=2u model=nmos
* Wait, standard 2-stage: Diff pair drains connect to a current mirror load. The output of the first stage is taken from one drain.
* Let's restructure for clarity and gain:
* Stage 1: NMOS diff pair with PMOS active load (Current Mirror).
* Stage 2: NMOS common source driven by the drain of the first stage, loaded by a PMOS current source.

* Revised Topology for High Gain:
* Tail Current: Mtail (PMOS) at bottom? No, usually NMOS diff pair with PMOS tail current sink is hard without bias. 
* Let's use NMOS Diff Pair with PMOS Active Load (Current Mirror).
* Biasing: We need a reference current. Let's create a simple bias circuit using resistors to VDD and GND to set up the mirror.

* Reference Current Generator
Rref1 VDD ref_node 10k
Mref_p pmos ref_node VDD VDD VDD L={L} W=5u model=pmos
* This sets a current if we have a ground connection. Let's connect ref_node to GND via a resistor or just assume it's biased.
* Better approach: Use a dedicated bias node 'bias_v' connected to a voltage source? No external sources allowed except AC.
* We must generate DC bias internally. 
* Simplest robust way: Use a large PMOS diode-connected as reference and mirror it.

* Let's define the circuit clearly:
* VDD = 5V, GND = 0V (implied by model params).
* Tail Current Source: A PMOS current source connected between VDD and the tail of NMOS diff pair? 
* No, standard is NMOS diff pair with PMOS active load. The tail needs a current sink (NMOS) to GND or PMOS to VDD?
* If NMOS diff pair, sources are at bottom. Need a current sink to GND. Let's use an NMOS current sink.
* But we need bias for that NMOS. 
* Alternative: PMOS Diff Pair with NMOS Active Load (Current Mirror). This is easier to bias from VDD.
* Let's switch to PMOS Differential Input Pair for easier high-side biasing, or stick to NMOS and add a resistor divider for bias?
* The prompt says "non-inverting input is node in". It doesn't specify NMOS/PMOS type, just CMOS.
* Let's design an NMOS differential pair with a PMOS active load (Current Mirror). 
* To bias the tail: We need a current source. Let's use a simple resistor to GND for the tail if we can't define complex biasing, but that wastes gain.
* Best approach for "Design": Include a simple bias network.
* Bias Network: Resistor divider from VDD to GND to generate a gate voltage for the tail current source (NMOS).
* Let's assume the tail current source is an NMOS transistor Mtail connected between the diff pair sources and GND.
* Gate of Mtail needs a bias voltage. We create one using a resistor divider or a diode-connected PMOS.
* Let's use a simple resistor divider to generate Vbias for the tail current source.

* Final Circuit Plan:
1. VDD = 5V, GND = 0V (implicit).
2. Bias Generation: Resistor divider Rb1, Rb2 from VDD to GND creating Vbias.
3. Tail Current Source: NMOS Mtail with gate at Vbias, source at GND, drain connected to sources of diff pair.
4. Diff Pair: Two NMOS (Mdiff1, Mdiff2). Gates: 'in' and 'in_' (grounded for single-ended AC). Sources connected to Mtail drain.
5. Active Load: PMOS Current Mirror (Mload1, Mload2) connected between VDD and diff pair drains.
   - Mload1 gate connected to Mload2 gate (diode connected Mload1).
   - Mload1 drain connected to Mdiff1 drain (Node X).
   - Mload2 drain connected to Mdiff2 drain (Node Y).
6. Second Stage: Common Source NMOS (Mcs) with PMOS Active Load (Mcs_load).
   - Input: Node X (drain of Mdiff1/Mload1 junction? No, usually we take the output of the first stage from one side).
   - Standard Miller Compensated Op-Amp: 
     - Stage 1 Output is taken from the drain of Mdiff1 (Node X) which is also the gate of Mcs.
     - Wait, if Mload1 and Mdiff1 are in parallel at Node X, that's the output of stage 1.
     - Mcs gate connects to Node X.
     - Mcs drain connects to Output 'out'.
     - Mcs load is a PMOS current source (Mcs_load) connected between VDD and 'out'.
7. Miller Compensation: Capacitor Cc from 'out' to the gate of Mcs (Node X).

* Component Values for ~60dB Gain:
* W/L ratios need to be sized. Let's use reasonable values (e.g., 10u/0.18u).
* Cc needs to be small enough not to dominate but large enough for stability (e.g., 2pF - 5pF).

* Netlist Construction:
* Nodes: 
  - in (input)
  - out (output)
  - tail_node (diff pair sources)
  - node_x (drain of Mdiff1 / gate of Mcs / top of Cc) -> This is the internal node for Miller cap.
  - node_y (drain of Mdiff2, usually AC ground if in- is grounded, but we keep it).
  - bias_node (for tail current gate)

* Let's refine the biasing to be self-contained without external voltage sources other than VDD/GND implied by models and connections.
* We will use a resistor divider for the tail current source gate.
* Rb1 from VDD to bias_node, Rb2 from bias_node to GND.
* Actually, to make it strictly "inside the netlist" without defining VDD as a voltage source line (usually .dc or just connecting to nodes), we assume VDD and 0 are available nodes. The prompt says "VDD = 5 V", implying a supply rail. In SPICE, we usually define a voltage source `Vdd 0 VDD DC 5`.

* Let's write the netlist.

