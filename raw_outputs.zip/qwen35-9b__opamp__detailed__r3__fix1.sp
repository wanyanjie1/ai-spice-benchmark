* Two-Stage Miller-Compensated CMOS Op Amp Design
* Specs: Gain >= 60dB, VDD=5V, CL=1pF
* Models provided in prompt used directly.
.model NMOS1 nmos (level=1 vto=0.7 kp=110u lambda=0.04)
.model PMOS1 pmos (level=1 vto=-0.7 kp=50u lambda=0.05)
* --- Biasing and Current Mirrors ---
* Reference Branch: Generates I_ref ~ 20uA.
* M_ref_p: Diode-connected PMOS.
* M_ref_n: Diode-connected NMOS.
* Sizes calculated for VDD=5V to achieve approx 20uA with Vov~0.2V.
* Id = 0.5 * KP * (W/L) * Vov^2.
* For PMOS (KP=50u): 20u = 0.5 * 50u * (W/L) * 0.04 => W/L = 20. Let W=20u, L=1u.
* For NMOS (KP=110u): 20u = 0.5 * 110u * (W/L) * 0.04 => W/L = 9.09. Let W=9u, L=1u.
M_ref_p drain=VDD gate=VDD source=Node_X PMOS1 W=20u L=1u
M_ref_n drain=Node_X gate=Node_X source=GND NMOS1 W=9u L=1u
* Current Mirror Branch: Replicates I_ref to the Tail Current Source.
* M_mirr_p: Matches M_ref_p (PMOS).
* M_tail: Matches M_ref_n (NMOS), acts as the tail current source for the diff pair.
M_mirr_p drain=VDD gate=Node_X source=Node_Y PMOS1 W=20u L=1u
M_tail drain=Node_Y gate=Node_Y source=GND NMOS1 W=9u L=1u
* --- Stage 1: Differential Pair with PMOS Current Mirror Load ---
* Inputs: `in` (non-inverting), `inn` (inverting).
* M_in1, M_in2: Input NMOS differential pair.
* M_load_p1, M_load_p2: PMOS active load current mirror.
* Sizing for Gain and Headroom:
* To get high gain, we need large W/L for input transistors to increase gm (if biased higher) or simply ensure saturation.
* However, with fixed current (20uA), gm is fixed by I. We need large output resistance.
* Let's size input NMOS (M_in1, M_in2) to have reasonable Vov (e.g., 0.3V).
* Id = 20uA. 20u = 0.5 * 110u * (W/L) * 0.3^2 => W/L = 40 / (110 * 0.09) = 4.08. Let W=4u, L=1u.
* Load PMOS (M_load_p1, M_load_p2): Need to match the current mirror ratio (1:1).
* Since M_mirr_p and M_tail are matched (W/L=20), the load PMOS should also be sized similarly to pass 20uA?
* Wait, the load is a current mirror. The reference branch sets the gate voltage for the load PMOS.
* So M_load_p1 and M_load_p2 must match M_mirr_p (W=20u, L=1u) to ensure they pass the same current as the tail source?
* Actually, the tail current is 20uA. The total current in the diff pair is 20uA.
* So each side carries 10uA when balanced? No, the tail current splits.
* If M_tail passes 20uA, then I_total = 20uA.
* In a symmetric diff pair, if Vin=0, I_D1 = I_D2 = 10uA.
* But our bias circuit was sized for 20uA total?
* Let's re-evaluate the bias sizing.
* If M_ref_p and M_ref_n are in series, they carry the SAME current.
* If we size them for 20uA, then I_tail = 20uA.
* Then the diff pair splits this into 10uA each side.
* So the load PMOS must pass 10uA? No, the load is a mirror.
* The gate of M_load_p1 is connected to Node_X (from Ref Branch).
* The current through M_load_p1 depends on its W/L and Vgs.
* If M_load_p1 matches M_mirr_p (W=20u), it will try to pass 20uA?
* But the available current from the tail is only 20uA total (split between two branches).
* This implies a mismatch if we assume ideal mirrors.
* Correction: The reference branch sets Vgs for the PMOS load.
* If M_ref_p and M_mirr_p are matched, they have same Vgs.
* If M_ref_n and M_tail are matched, they have same Vgs.
* Then I_load = I_tail = 20uA?
* But the diff pair needs to sink 20uA total. The load must source 20uA total.
* So each PMOS load should pass 10uA? No, the mirror forces them to be equal.
* If the reference branch passes 20uA, then both loads will try to pass 20uA.
* But the tail only provides 20uA total. This creates a conflict (KCL violation at output node if not careful).
* Actually, in a standard op-amp:
*   Tail Current = I_tail.
*   Diff Pair splits I_tail into I_D1 and I_D2. Sum = I_tail.
*   Load PMOS mirror sources current to match the NMOS drain currents.
*   If M_load_p1 is diode connected in the reference branch? No, usually the reference branch is separate.
*   Standard Topology:
*     Ref Branch: VDD -> PMOS(M_ref) -> Node_Bias -> NMOS(M_tail_ref) -> GND. (M_ref diode connected).
*     This sets I_ref and Vbias.
*     Tail Current Source: M_tail (NMOS) gate connected to Vbias.
*     Load Mirror: VDD -> PMOS(M_load_p1) -> Node_Out1 -> NMOS(M_in1) -> GND.
*                VDD -> PMOS(M_load_p2) -> Node_Out2 -> NMOS(M_in2) -> GND.
*     Gate of M_load_p1 connected to Gate of M_load_p2.
*     Where is the reference for the load mirror? Usually, one of the loads is diode connected to set Vgs for the pair.
*     Let's make M_load_p1 diode connected (Drain=Gate) and M_load_p2 as the active load.
*     Then I_D1 = I_D2.
*     We need to size M_load_p1 such that it passes half of I_tail? No, if M_load_p1 is diode connected, it sets Vgs for the pair.
*     If we want I_tail = 20uA, then I_D1 = I_D2 = 10uA (at balance).
*     So M_load_p1 must be sized to pass 10uA with its specific Vgs.
*     But our reference branch was sized for 20uA.
*     Let's adjust the reference branch to generate a current that splits correctly, OR size the loads to match the tail current directly.
*     Simpler approach: Size the Reference Branch to pass exactly the desired Tail Current (20uA).
*     Then M_load_p1 and M_load_p2 must be sized to pass 10uA each? No, they are a mirror.
*     If M_load_p1 is diode connected, it sets Vgs.
*     If we want I_D = 10uA, we need W/L such that Id=10uA.
*     Let's recalculate sizes for 10uA (since total tail is 20uA).
*     NMOS Input (M_in1, M_in2): Id = 10uA.
*       10u = 0.5 * 110u * (W/L) * Vov^2. Let Vov=0.3V.
*       W/L = 20 / (110 * 0.09) = 2.02. Let W=2u, L=1u.
*     PMOS Load (M_load_p1, M_load_p2): Id = 10uA.
*       10u = 0.5 * 50u * (W/L) * Vov^2. Let Vov=0.3V.
*       W/L = 20 / (50 * 0.09) = 4.44. Let W=4u, L=1u.
*     Now, how to bias?
*     We need a reference branch that generates the correct Vgs for these loads.
*     Ref Branch: VDD -> PMOS(M_ref_p) -> Node_Bias -> NMOS(M_ref_n) -> GND.
*     This branch must pass 10uA (to match the load current).
*     Size M_ref_p (PMOS): Id=10uA, W/L = 4.44 -> W=4u, L=1u.
*     Size M_ref_n (NMOS): Id=10uA, W/L = 2.02 -> W=2u, L=1u.
*     Connect Gate of M_load_p1 to Node_Bias.
*     Make M_load_p1 diode connected? No, usually one load is diode connected to set Vgs, the other mirrors it.
*     But in a diff pair with active load, we connect Gate(M_load_p1) = Gate(M_load_p2).
*     One of them (say M_load_p1) is diode connected to the output node? No, that shorts the output.
*     Standard: M_load_p1 drain connected to M_in1 drain (Node Out1). Gate connected to Node_Bias.
*     M_load_p2 drain connected to M_in2 drain (Node Out2). Gate connected to Node_Bias.
*     But we need a reference for the mirror. Usually, one PMOS is diode connected to a dummy NMOS or just diode connected to set Vgs?
*     If we connect Gate(M_load_p1) = Drain(M_load_p1), then it's diode connected.
*     Then M_load_p2 mirrors it.
*     But where does the current come from? The tail source.
*     So:
*       Ref Branch: VDD -> PMOS(M_refp, W=4u) -> Node_Bias -> NMOS(M_refn, W=2u) -> GND. (Both diode connected).
*       This sets I_ref = 10uA and Vbias.
*       Tail Source: M_tail (NMOS) gate to Node_Bias? No, M_tail needs to pass 20uA total.
*       Wait, if Ref Branch passes 10uA, then Vbias is set for 10uA.
*       If we use M_tail with same W/L as M_refn (W=2u), it will also pass 10uA.
*       But we need 20uA tail current to split into 10uA each side? Yes.
*       So I_tail = 10uA + 10uA = 20uA.
*       This works perfectly.
*       So:
*         M_ref_p (PMOS): W=4u, L=1u. Diode connected.
*         M_ref_n (NMOS): W=2u, L=1u. Diode connected.
*         M_tail (NMOS): Match M_ref_n -> W=2u, L=1u. Gate to Node_Bias.
*         M_load_p1 (PMOS): Match M_ref_p -> W=4u, L=1u. Gate to Node_Bias. Diode connected?
*           If M_load_p1 is diode connected, it sets Vgs for the mirror.
*           But M_load_p1 drain is at Node_Out1. If we connect Gate to Drain, Node_Out1 = Node_Bias.
*           This shorts the output to the bias node. Not good for AC gain.
*           Correction: In a standard op-amp, one side of the load mirror is diode connected to a dummy current source or just diode connected to VDD/GND?
*           Actually, the standard way is:
*             M_load_p1 (Diode Connected): Drain=Gate=Node_Bias. Source=VDD.
*             M_load_p2 (Active Load): Gate=Node_Bias. Drain=Node_Out2.
*             But then where is the diff pair?
*             The diff pair drains connect to these nodes.
*             So Node_Out1 connects to M_in1 drain and M_load_p1 drain.
*             If M_load_p1 is diode connected, Node_Out1 = Node_Bias.
*             Then M_in1 drain is at Node_Bias.
*             This means the output voltage is fixed at Vbias. No swing!
*             We need a different topology for the load mirror reference.
*             Usually, we use a separate bias circuit to generate Vbias, and both loads are connected to it.
*             But one of the loads must be diode connected to establish the current?
*             No, in a fully differential or single-ended output op-amp with active load:
*               The load is a PMOS current mirror.
*               One PMOS (M_load_p1) is diode connected to its own drain? No, that fixes the voltage.
*               Instead, we often use a "dummy" branch or accept that the output DC level is determined by the intersection of the NMOS and PMOS curves.
*               However, for a current mirror load:
*                 M_load_p1 (Diode Connected): Drain=Gate connected to a node that sets Vgs.
*                 But if we connect it to the diff pair output, we lose swing.
*                 Solution: Use a separate reference branch for the PMOS mirror gate voltage, and make one of the load transistors diode connected to a *dummy* NMOS or just rely on the fact that the DC operating point will settle where I_Dn = I_Dp.
*                 Wait, if M_load_p1 is diode connected (Drain=Gate), then Vgs_p is fixed.
*                 Then M_in1 must pass exactly that current.
*                 This defines the DC output voltage.
*                 So yes, one load transistor IS diode connected to define the DC bias point.
*                 But which node? The output node `out` is usually taken from the drain of the second stage or the first stage.
*                 For the first stage (Diff Pair), the output is at the drains of M_in1/M_in2 and M_load_p1/M_load_p2.
*                 If we take `out` from the drain of M_in1 (Node_Out1), and M_load_p1 is diode connected there, then `out` = Vbias.
*                 This is acceptable for DC analysis, but limits swing.
*                 However, to get high gain, we need the output resistance of the load to be high. A diode-connected transistor has low R_out.
*                 Standard Miller Op-Amp First Stage:
*                   Diff Pair + Active Load (Current Mirror).
*                   The current mirror is formed by M_load_p1 and M_load_p2.
*                   Usually, M_load_p1 is diode connected to set the gate voltage for M_load_p2.
*                   But if M_load_p1 is diode connected at the output node, the output resistance is low (ro || 1/gm).
*                   This kills gain.
*                   Correct Topology: The current mirror load consists of two PMOS transistors. One is diode-connected? No.
*                   Actually, in a standard 2-stage op-amp, the first stage output node is connected to the drain of one input NMOS and one load PMOS.
*                   The other side is mirrored.
*                   To get high gain, we want the load to be a current source (high Ro).
*                   If we use a simple current mirror load, one transistor must be diode-connected to set Vgs?
*                   Yes, but that reduces gain.
*                   Wait, maybe I am confusing with fully differential.
*                   In single-ended output:
*                     M_in1 drain -> Node A.
*                     M_load_p1 drain -> Node A.
*                     M_in2 drain -> Node B.
*                     M_load_p2 drain -> Node B.
*                     Gate(M_load_p1) = Gate(M_load_p2).
*                     One of them (say M_load_p1) is diode connected? No, that would short Node A to the gate.
*                     Instead, we usually have a separate bias circuit for the PMOS gates.
*                     And we rely on the fact that I_D1 = I_D2 due to symmetry?
*                     But without one being diode connected, how do we set Vgs?
*                     We need a reference current branch.
*