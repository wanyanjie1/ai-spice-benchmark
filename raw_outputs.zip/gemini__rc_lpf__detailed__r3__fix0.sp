* First-Order Passive RC Low-Pass Filter
*
* Hand Calculation:
* Specification: fc = 1 kHz, Passband Gain = 0 dB
* Formula: fc = 1 / (2 * pi * R * C)
* Choose standard capacitor value: C = 100 nF
* Calculate R:
* R = 1 / (2 * pi * fc * C)
* R = 1 / (2 * pi * 1000 Hz * 100 nF)
* R = 1 / (6.283185e-4) = 1591.55 ohms

* Input Voltage Source
V1 in 0 AC 1

* Passive RC Filter Network
R1 in out 1591.55
C1 out 0 100n

* AC Analysis from 10 Hz to 100 kHz
.ac dec 20 10 100k

.end
