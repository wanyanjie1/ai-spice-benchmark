* Two-Stage Miller-Compensated CMOS Op Amp Design
* Specs: Gain >= 60dB, VDD=5V, CL=1pF
* Models provided in prompt used directly.

.model NMOS1 nmos (level=1 vto=0.7 kp=110u lambda=0.04)
.model PMOS1 pmos (level=1 vto=-0.7 kp=50u lambda=0.05)

* --- Power Supplies ---
VDD VDD 0 DC 5

* --- Biasing Network ---
* We need two bias voltages:
* 1. Vtail_bias: For the NMOS tail current source and the gates of the PMOS load mirror.
*    We create a reference branch here to set this voltage.
*    Target Current for Tail: 20uA total (10uA per side).
*    The PMOS loads also need to pass 10uA each.
*    So, the bias network must generate a Vgs that allows 10uA through the load devices.

* Reference Branch for Tail Bias (Sets Vtail_bias)
* We use a diode-connected PMOS and an NMOS to set the gate voltage for the tail source.
* To ensure the loads (PMOS) pass 10uA, we size this reference PMOS to pass 10uA when diode connected.
* Id = 10uA. KP=50u. Assume Vov ~ 0.3V.
* W/L = 2*Id / (KP * Vov^2) = 20u / (50u * 0.09) = 4.44. Let's use W=4.5u, L=1u.
M_ref_p drain=VDD gate=Node_Tail_Bias source=Node_Tail_Bias PMOS1 W=4.5u L=1u

* Reference NMOS for the same node (completes the branch to ground)
* Id = 10uA. KP=110u. Assume Vov ~ 0.3V.
* W/L = 2*Id / (KP * Vov^2) = 20u / (110u * 0.09) = 2.02. Let's use W=2u, L=1u.
M_ref_n drain=Node_Tail_Bias gate=Node_Tail_Bias source=0 NMOS1 W=2u L=1u

* --- Stage 1: Differential Pair with PMOS Current Mirror Load ---
* Inputs: `in` (non-inverting), `inn` (inverting).
* M_in1, M_in2: Input NMOS differential pair.
* Sizing for Gain and Headroom:
* Total Tail Current = 20uA. Balanced current per side = 10uA.
* Id = 10uA. KP=110u. Vov ~ 0.3V.
* W/L = 2*10u / (110u * 0.09) = 2.02. Let's use W=2u, L=1u.
M_in1 drain=Node_Out1 gate=in source=0 NMOS1 W=2u L=1u
M_in2 drain=Node_Out2 gate=inn source=0 NMOS1 W=2u L=1u

* PMOS Load Mirror:
* M_load_p1: Diode connected to Node_Out1. This sets the DC operating point for the first stage output.
* It must match M_ref_p (the reference PMOS in the bias network) to ensure correct current mirroring ratio (1:1).
* Since M_ref_p has W=4.5u, L=1u, we use the same dimensions here.
M_load_p1 drain=Node_Out1 gate=Node_Out1 source=VDD PMOS1 W=4.5u L=1u

* M_load_p2: Active load for the inverting input side. Mirrors M_load_p1.
* Gate connected to Node_Out1 (same as M_load_p1 gate).
M_load_p2 drain=Node_Out2 gate=Node_Out1 source=VDD PMOS1 W=4.5u L=1u

* --- Tail Current Source ---
* M_tail: NMOS current source for the differential pair.
* Gate connected to Node_Tail_Bias.
* Must match M_ref_n (the reference NMOS in the bias network) to ensure 20uA total tail current.
M_tail drain=Node_Y gate=Node_Tail_Bias source=0 NMOS1 W=2u L=1u

* --- Compensation and Second Stage ---
* Miller Capacitor Cc from Node_Out1 to `out`.
Cc Node_Out1 out 2pF

* Second Stage: Common Source Amplifier
* Input: Node_Out1 (from Stage 1) drives the gate of M_out_in.
* Load: PMOS Current Source (M_out_load).
* We need a separate bias voltage for the second stage load to allow independent sizing if needed,
* but here we sized it directly. Let's target I_stage2 = 50uA for better bandwidth.
* NMOS Input of Stage 2 (M_out_in):
*   Id = 50uA. Vov ~ 0.3V.
*   W/L = 2*50u / (110u * 0.09) = 10.18. Let's use W=10u, L=1u.
M_out_in drain=out gate=Node_Out1 source=0 NMOS1 W=10u L=1u

* PMOS Load of Stage 2 (M_out_load):
*   Must pass 50uA. Vov ~ 0.3V.
*   W/L = 2*50u / (50u * 0.09) = 22.22. Let's use W=22u, L=1u.
M_out_load drain=out gate=Node_Load_Bias_2 source=VDD PMOS1 W=22u L=1u

* Bias for Second Stage Load (M_out_load):
*   We need a separate bias node for Node_Load_Bias_2 to generate Vgs for M_out_load.
*   Create a small reference branch for Node_Load_Bias_2.
*   We want M_out_load (W=22u) to pass 50uA.
*   Let's create a dummy PMOS diode connected at Node_Load_Bias_2 that passes a reference current I_ref2.
*   Current Ratio = (W/L)_load / (W/L)_dummy_p = 22u / W_dummy.
*   If we set W_dummy = 1u, Ratio = 22.
*   Then I_load = 22 * I_ref2. We need I_load = 50uA => I_ref2 = 2.27uA.
*   Let's size the dummy PMOS to pass ~2.3uA.
*   Vov ~ 0.3V. KP=50u.
*   W/L = 2*2.3u / (50u * 0.09) = 1.02. Let's use W=1u, L=1u.
M_dummy_p drain=VDD gate=Node_Load_Bias_2 source=Node_Load_Bias_2 PMOS1 W=1u L=1u

* Dummy NMOS for the same node (completes the branch to ground)
M_dummy_n drain=Node_Load_Bias_2 gate=Node_Load_Bias_2 source=0 NMOS1 W=1u L=1u

* --- Input Test Bench ---
* Vin in 0 DC 2.5 AC 1   (non-inverting input = node in)
* Inverting input `inn`: 
* Connect inn to out through a 1G H inductor and inn to ground through a 1 F capacitor.
* Note: Inductors require a series resistance to avoid singularity matrix errors in DC analysis.
L_test out inn 1G H Rser=1m
C_test inn 0 1F

* --- Output Load Capacitor (CL) ---
* Connected from output `out` to ground.
C_load out 0 1pF
