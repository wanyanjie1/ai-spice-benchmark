.model R1 resistor r=1k
.model C1 capacitor c=1u
V1 in 0 ac 1
R2 out 0 r=1k
C2 out 0 c=1u
.model R3 resistor r=1k
.model C3 capacitor c=1u
V2 in 0 ac 1
R4 out 0 r=1k
C4 out 0 c=1u
.model R5 resistor r=1k
.model C5 capacitor c=1u
V3 in 0 ac 1
R6 out 0 r=1k
C6 out 0 c=1u
.model R7 resistor r=1k
.model C7 capacitor c=1u
V4 in 0 ac 1
R8 out 0 r=1k
C8 out 0 c=1u
.model R9 resistor r=1k
.model C9 capacitor c=1u
V5 in 0 ac 1
R10 out 0 r=1k
C10 out 0 c=1u