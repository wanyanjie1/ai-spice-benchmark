* Single-stage Common-Source NMOS Amplifier Design
* Specs: |Av| = 10, VDD = 5V, f = 1kHz (AC analysis)
* Model: level=1, vto=0.7, kp=200u, lambda=0.01
* --- Hand Calculation & Component Selection Comments ---
* Design Goal: |Av| = gm * RD ≈ 10
* Constraint Analysis:
*   With VDD=5V and VTO=0.7V, achieving high gain requires operating at low current
*   to allow a large Drain Resistor (RD) while maintaining saturation (VDS > VGS-VTO).
*   Iteration:
*   Let's choose an overdrive voltage Vov = VGS - VTO = 0.2 V.
*   Then VGS = 0.7 + 0.2 = 0.9 V.
*   Calculate ID using Level 1 model (Saturation): ID = 0.5 * kp * W/L * (Vov)^2
*   Assuming W=1u, L=1u for the model definition (default aspect ratio 1), 
*   ID = 0.5 * 200uA/V^2 * (0.2)^2 = 4 uA.
*   Calculate gm: gm = 2 * ID / Vov = 2 * 4uA / 0.2V = 40 uS.
*   Required RD for Av=10: RD = 10 / gm = 10 / 40uS = 250 kΩ.
*   Check Voltage Headroom:
*   V_drop_RD = ID * RD = 4uA * 250kΩ = 1.0 V.
*   V_Drain (Vout) = VDD - V_drop_RD = 5V - 1.0V = 4.0 V.
*   Saturation Check: VDS = 4.0V. Vov = 0.2V. 
*   Is VDS > Vov? 4.0 > 0.2. Yes, device is in deep saturation.
*   Bias Divider for Gate (VG = 0.9V):
*   To minimize loading effect on the gate (though negligible for MOSFET), 
*   we choose a divider current significantly higher than ID (e.g., 100x).
*   Let's use I_div = 100uA.
*   R2 (Gate to Ground) = VG / I_div = 0.9V / 100uA = 9 kΩ.
*   R1 (VDD to Gate) = (VDD - VG) / I_div = 4.1V / 100uA = 41 kΩ.
*   Input Coupling Capacitor: 10uF (given).
*   Output Node: Drain connected directly to node `out`.
* --- SPICE Netlist Construction ---
* Power Supply
VDD VDD 0 DC 5
* Input Source: AC 1 at node 'in'
Vin in 0 AC 1
* Coupling Capacitor from input to gate
Cin in gate 10u
* NMOS Transistor
* Drain connects to RD and Output node 'out'
* Gate connects to Bias Network and Cin
* Source connects to Ground
M1 out gate 0 0 NMOS1 L=1u W=1u
* Drain Resistor (sets gain)
RD out VDD 250k
* Gate Bias Divider
R1 VDD gate 41k
R2 gate 0 9k
* Device Model Definition
.model NMOS1 nmos (level=1 vto=0.7 kp=200u lambda=0.01)
* AC Analysis Setup
.ac dec 1 1k 1k
* Print Magnitude of Gain (Optional, for verification)
.print ac V(out) V(in)
.end