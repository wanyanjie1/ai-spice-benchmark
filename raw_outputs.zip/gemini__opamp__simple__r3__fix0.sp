* Two-Stage CMOS Operational Amplifier
* Differential Input Pair + Common-Source Second Stage (Miller Compensated)

* Transistor Models
.model NMOS NMOS (VTO=0.7 KP=100U LAMBDA=0.02)
.model PMOS PMOS (VTO=-0.7 KP=40U LAMBDA=0.02)

* Power Supplies & Bias
Vdd vdd 0 DC 5
Vbias vbias 0 DC 3.8

* Signal Inputs
Vin in 0 DC 2.5 AC 1
Vin_m in_m 0 DC 2.5

* First Stage: PMOS Differential Pair with NMOS Current Mirror Load
M5 tail vbias vdd vdd PMOS W=20u L=1u
M1 n1 in_m tail vdd PMOS W=50u L=1u
M2 n2 in tail vdd PMOS W=50u L=1u
M3 n1 n1 0 0 NMOS W=10u L=1u
M4 n2 n1 0 0 NMOS W=10u L=1u

* Second Stage: NMOS Common-Source Amplifier with PMOS Current Source Load
M6 out n2 0 0 NMOS W=40u L=1u
M7 out vbias vdd vdd PMOS W=40u L=1u

* Miller Compensation Network
Cc n2 n_cc 2p
Rz n_cc out 2k

* Analysis Command
.ac dec 10 1 100MEG

.end
