* First-order Passive RC Low-Pass Filter (Corrected)
* Target Cutoff Frequency: 1 kHz
* Formula: f_c = 1 / (2 * pi * R * C)
* Let R = 1k Ohm, then C = 1 / (2 * pi * 1000 * 1000) Farads approx 159.1549 uF
Vsource in 0 AC 1
Rload out 0 1k
Cfilter in out 159.1549u
.ac dec 100 10 1Meg
.end