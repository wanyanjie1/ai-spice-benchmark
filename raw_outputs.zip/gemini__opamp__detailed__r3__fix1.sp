* Two-Stage Miller-Compensated CMOS Operational Amplifier
* Hand Calculations & Design Fixing:
* -----------------------------------------------------------------------------
* Technology Parameters:
*   NMOS: Vtn = 0.7V, Kp_n = 110u A/V^2, lambda_n = 0.04 V^-1
*   PMOS: Vtp = -0.7V, Kp_p = 50u A/V^2, lambda_p = 0.05 V^-1
* Supply: VDD = 5V, VSS = 0V
*
* Polarity Correction:
*   - Gate of M2 = 'in' (Non-Inverting Input (+)): 
*       V(in)^ -> I(M2)^ -> V(out1)v -> VSG6^ -> V(out)^  (Positive Gain)
*   - Gate of M1 = 'inn' (Inverting Input (-)): 
*       V(inn)^ -> I(M1)^ -> V(out1_n)v -> I(M4)^ -> V(out1)^ -> VSG6v -> V(out)v (Negative Gain)
*   - This ensures DC negative feedback through L1 from 'out' to 'inn'.
*
* 1. Bias Circuit (M8 & Iref = 20uA):
*    (W/L)8 = 10u / 2u = 5
*    ID8 = 20uA  =>  Vov8 = sqrt(20u / (0.5 * 110u * 5)) = 0.27 V
*    Vbias_n = 0.7 + 0.27 = 0.97 V
*
* 2. First Stage Tail & Diff Pair (M5, M1, M2, M3, M4):
*    Tail M5: (W/L)5 = 10u / 2u = 5 => ID5 = 20uA
*    Diff Pair M1, M2: ID1 = ID2 = 10uA, (W/L)1,2 = 30u / 2u = 15
*    gm1,2 = sqrt(2 * 110u * 15 * 10u) = 181.6 uS
*    PMOS Load M3, M4: (W/L)3,4 = 10u / 2u = 5
*    Vov3,4 = sqrt(2 * 10u / (50u * 5)) = 0.283 V => V(out1) = 5 - 0.7 - 0.283 = 4.017 V
*
*    First Stage Output Resistance & Gain:
*    ro2 = 1 / (0.04 * 10u) = 2.5 Mohm
*    ro4 = 1 / (0.05 * 10u) = 2.0 Mohm
*    Ro1 = ro2 || ro4 = 1.111 Mohm
*    Av1 = gm1 * Ro1 = 181.6u * 1.111M = 201.8 V/V (46.1 dB)
*
* 3. Second Stage (M6, M7):
*    NMOS Load M7: (W/L)7 = 50u / 2u = 25 => ID7 = 100uA
*    PMOS Driver M6: VSG6 = 5 - 4.017 = 0.983 V => Vov6 = 0.283 V
*    (W/L)6 = 100u / (0.5 * 50u * 0.283^2) = 100u / 2u = 50
*    gm6 = sqrt(2 * 50u * 50 * 100u) = 707.1 uS
*    ro6 = 1 / (0.05 * 100u) = 200 kohm, ro7 = 1 / (0.04 * 100u) = 250 kohm
*    Ro2 = ro6 || ro7 = 111.1 kohm
*    Av2 = gm6 * Ro2 = 707.1u * 111.1k = 78.6 V/V (37.9 dB)
*
* 4. Total DC Open-Loop Gain:
*    Av = Av1 * Av2 = 201.8 * 78.6 = 15860 V/V = 84.0 dB (Spec >= 60 dB)
* -----------------------------------------------------------------------------

* Model Definitions
.model NMOS1 nmos level=1 vto=0.7 kp=110u lambda=0.04
.model PMOS1 pmos level=1 vto=-0.7 kp=50u lambda=0.05

* Power Supply & Reference Current
Vdd vdd 0 DC 5
Iref vdd vbias_n DC 20u

* Bias Mirror Transistor
M8 vbias_n vbias_n 0 0 NMOS1 W=10u L=2u

* First Stage: Differential Pair with PMOS Mirror Load
M1 out1_n inn tail 0 NMOS1 W=30u L=2u
M2 out1 in tail 0 NMOS1 W=30u L=2u
M3 out1_n out1_n vdd vdd PMOS1 W=10u L=2u
M4 out1 out1_n vdd vdd PMOS1 W=10u L=2u
M5 tail vbias_n 0 0 NMOS1 W=10u L=2u

* Second Stage: PMOS Common-Source with NMOS Current Load
M6 out out1 vdd vdd PMOS1 W=100u L=2u
M7 out vbias_n 0 0 NMOS1 W=50u L=2u

* Compensation & Load Capacitors
Cc out1 out 2p
CL out 0 1p

* Open-Loop AC Test Bench (with DC Negative Feedback)
Vin in 0 DC 2.5 AC 1
L1 out inn 1G
C1 inn 0 1

.op
.ac dec 20 1 100Meg

.end
