* Common-Source NMOS Amplifier (Gain = 10 / 20 dB at 1 kHz)

* Power Supply
Vdd vdd 0 DC 5

* AC Input Source
Vin in 0 DC 0 AC 1

* Input Coupling Capacitor
Cin in g 10u

* Gate Bias Voltage Divider (Vg = 1.5V)
R1 vdd g 700k
R2 g 0 300k

* Drain Load Resistor
RD vdd out 10k

* NMOS Transistor (D G S B)
M1 out g 0 0 nmos_model

* Transistor Model Definition (gm = KP*(Vgs-Vth) = 2m*(1.5-1.0) = 1 mS, Av = gm*RD = 10)
.model nmos_model NMOS (VTO=1.0 KP=2m LAMBDA=0)

* AC Analysis at 1 kHz
.ac lin 1 1k 1k

.end
