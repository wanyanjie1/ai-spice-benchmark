* Two-stage CMOS operational amplifier with differential input pair and common-source second stage, Miller compensated
* Open-loop DC gain of at least 60 dB, VDD = 5 V

* Define NMOS and PMOS transistors
.model NMOS NMOS L=1u W=10u
.model PMOS PMOS L=1u W=10u

* Define capacitors
.model C1 C 1p

* Differential input pair
M1 in1 in2 vdd vdd NMOS
M2 in1 in2 vss vss PMOS

* Common-source second stage
M3 vdd out vdd vdd NMOS
M4 vss out vss vss PMOS

* Miller compensation
M5 vdd out vdd vdd NMOS
M6 vss out vss vss PMOS

* AC source
.ac dec 10 1 100MHz

* Output node
.out out
