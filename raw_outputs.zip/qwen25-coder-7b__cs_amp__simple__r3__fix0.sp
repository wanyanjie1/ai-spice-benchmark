.model NMOS NMOS (L=1u W=10u Kp=100u Vto=2)
VDD 1 0 DC 5
VSS 2 0 DC 0
VDD2 3 0 DC 5
VSS2 4 0 DC 0
Rin 1 5 1k
Rout 6 0 1k
Cin 5 7 1p
Cout 6 8 1p
M1 5 7 2 3 NMOS
M2 6 8 4 3 NMOS
.tran 1ms 10ms
.end