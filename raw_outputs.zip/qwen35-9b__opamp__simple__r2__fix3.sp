* Two-Stage CMOS Operational Amplifier
* Topology: NMOS Diff Pair + PMOS Mirror Load + PMOS CS 2nd Stage + NMOS Active Load
* Supply: VDD = 5V
* Target Gain: > 60dB

* --- Device Models (Level 1 for robust simulation) ---
.model nmos NMOS (LEVEL=1 VTO=0.4 KP=100u GAMMA=0.5 LAMBDA=0.02 CGSO=2p CGDO=2p CJ=1e-3 CJSW=1e-3)
.model pmos PMOS (LEVEL=1 VTO=-0.4 KP=-50u GAMMA=0.5 LAMBDA=0.02 CGSO=2p CGDO=2p CJ=1e-3 CJSW=1e-3)

* --- DC Supply Nodes ---
VDD vdd 0 DC 5
VGND gnd 0 DC 0

* --- Bias Voltage Sources (DC Levels set to ensure Saturation) ---
* VB_tail: Gate voltage for Tail Current Source and Input Pair Gates
VB_tail tail_gate 0 DC 1.2 
* VB_load: Gate voltage for PMOS Load Mirror (Diode connected one)
VB_load load_gate 0 DC 4.5
* VB_2nd_load: Gate voltage for NMOS Active Load of 2nd Stage
VB_2nd_load out_gate 0 DC 0.8

* --- First Stage: Differential Pair & Active Load ---
* M1, M2: NMOS Input Pair
* M3, M4: PMOS Current Mirror Load
* Node 'diff_out' is the output of the first stage (drain of M4)
* Node 'comp_node' is the internal node for Miller compensation (drain of M3 / gate of M4)

M1 drain diff_out in tail_node L=0.5u W=20u model=nmos
M2 drain diff_out in_ tail_node L=0.5u W=20u model=nmos

* PMOS Mirror Load
* M3: Diode-connected (Source to VDD, Drain/Gate to comp_node)
* M4: Mirrors M3 (Source to VDD, Drain to diff_out, Gate to comp_node)
M3 drain comp_node load_gate L=0.5u W=40u model=pmos
M4 drain diff_out comp_node L=0.5u W=40u model=pmos

* --- Tail Current Source ---
* Connects sources of M1 and M2 to Ground via VB_tail
M_tail drain tail_node gnd VB_tail L=0.5u W=80u model=nmos

* --- Second Stage: Common Source + Active Load ---
* Input is connected to 'diff_out' (drain of M4)
* M5: PMOS Common Source (Input at Gate, Source at VDD)
* M6: NMOS Active Load (Diode-connected, Drain/Gate at Output, Source at GND)

M5 drain out diff_out L=0.5u W=40u model=pmos
M6 drain out gnd VB_2nd_load L=0.5u W=80u model=nmos

* --- Input/Output Sources ---
* AC Source drives node 'in' with AC 1 and DC bias of 1.2V
AC_IN in 0 AC 1 DC 1.2

* --- Miller Compensation Capacitor ---
* Connects the internal node (comp_node) to the output (out)
C_comp comp_node out 2pF

* --- Analysis Commands ---
.OPTIONS POST2=2 RELTOL=0.001
.TRAN 1n 1u
.AC DEC 100 1Hz 100MHz
.OP
.END
